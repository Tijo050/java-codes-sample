package com.stackroute.Jacocosample2;

public class CalculatorSample {

	int num1;
	int num2;
	public CalculatorSample(int n1,int n2)
	{
		this.num1=n1;
		this.num2=n2;
		
	}
	
	public int addNumber()
	{
		return this.num1+ this.num2;
	}
	
	public int subtractnumber()
	{
		if(num1<num2)
			return num2-num1;
		else if(num1>num2)
			return num1-num2;
		else
			return 0;
	}
	
	public boolean validateData()
	{
		return !((num1<0) || (num2<0));
	}
	
	
	
}
