package com.stackroute.Jacocosample2;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;


public class CalculatorSampleTest {
	
CalculatorSample sampe=new CalculatorSample(10,30);
@Test
public void testAddnumber()
{
	assertEquals(40,sampe.addNumber());
}


@Test
public void testsubrtractsecondgreater()
{
	assertEquals(20,sampe.subtractnumber());
}

@Test
public void testsubstractfirstgreater()
{
	sampe.num1=40;
	assertEquals(10,sampe.subtractnumber());
}
@Test
public void testequal()
{
	sampe.num1=30;
	assertEquals(0,sampe.subtractnumber());
}

@Test
public void testinputvalid()
{
	assertTrue(sampe.validateData());
}

@Test
public void testinvaliddatanum1()
{
sampe.num1=-10;
assertFalse(sampe.validateData());
}

@Test
public void testinvalidatanum2()
{
	sampe.num2=-10;
	assertFalse(sampe.validateData());
}

@Test
public void invalidbothdata()
{
	sampe.num1=-10;
	sampe.num2=-20;
	assertFalse(sampe.validateData());
	
}

}
