package com.stackroute.Jsonsample;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JsonConverterSample {

	public static void main(String[] args) {
Map mydata=new HashMap();
mydata.put("empid","E01");
mydata.put("empname","Shanthi");
boolean ans=writeToJson(mydata);
	}
	
	static boolean writeToJson(Map map)
	{
		Gson gson=new GsonBuilder().setPrettyPrinting().create();
		String jsondata=gson.toJson(map);
		try
		{
			FileWriter fwrite=new FileWriter("emp.txt");
			BufferedWriter bwrite=new BufferedWriter(fwrite);
			bwrite.write(jsondata);
			bwrite.close();
			
		}
		catch(Exception io)
		{
			
		}
		System.out.println("Stored");
		return true;
	}

}



 


