package com.stackroute.SampleJacoco;

public class AppraisalProcess {

	int salary,experience;

    
	 boolean setData(int sal,int expr)
	 {
		 
		 if( (sal>0) && (expr>0) )
		 {
				 this.salary=sal;
		        this.experience=expr;
		       return true;
		 }
		 
		  else if(sal>0 && expr<0 )
			  return false;
		  else if (sal<0 && expr>0)
			  return false;
		  else
			  
			  	  return false;
		 
		  
		
		 
		 
	 }
	
   public String getAppraisalType(int mon)
   {
	   switch(mon)
	   {
	   case 3:
		   	return "Last year appraisal";
	   case 6:
		   return "current year appraisal";
		 default:
			 return "invalid period";
	   }
	   
   }
	 
	 
	 
	 public int appraisalPercentage()
	 {
		 if (experience>5)
		 return 10;
		 else
			 return 5;
	 }
	 public int calcuTax()
	{
//		 if(salary==0)
//			 return 0;
//			 else
				 
		return this.salary*10/100;
	}
//	
//	boolean checkData()
//	{
//		if(  (salary<=0) || (experience<=0) )
//return false;
//else
//	return true;
//	}
	
	
}
