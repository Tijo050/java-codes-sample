package com.stackroute.SampleJacoco;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;





public class AppraisalProcessTest {
AppraisalProcess aprocess=new AppraisalProcess();



@Test
public void testappraisalperiodthird()
{
	assertEquals("Last year appraisal", aprocess.getAppraisalType(3));
	
}

@Test
public void testappraisalperiodsx()
{
	assertEquals("current year appraisal", aprocess.getAppraisalType(6));
	
}

@Test
public void testappraisalperioddefault()
{
	assertEquals("invalid period", aprocess.getAppraisalType(10));
	
}


@Test
public void appraisaltest()
{
	aprocess.experience=4;
	assertEquals(5,aprocess.appraisalPercentage());
}

@Test
public void apprisalexprabovefivetest()
{
	aprocess.experience=21;
	assertEquals(10,aprocess.appraisalPercentage());
}


@Test
public void testdata()
{
	//aprocess.salary=5000;

assertEquals(true,aprocess.setData(2000, 5));
assertEquals(2000,aprocess.salary);
assertEquals(5,aprocess.experience);

}

@Test
public void testzerodatasalary()
{
	assertEquals(false,aprocess.setData(0, 3000));
}

@Test
public void testzerodataexpr()
{
	assertEquals(false,aprocess.setData(2000, 0));
}

@Test
public void testdatafailure()
{
	assertEquals(false, aprocess.setData(-1000, 10));
	//assertEquals(10,aprocess.experience);
}

@Test
public void testdatafailuresal()
{
	assertEquals(false,aprocess.setData(5000, -10));
}


@Test
public void testbothfailure()
{
	assertEquals(false,aprocess.setData(-1000, -50));
}



@Test
public void testtaxsalnegative()
{
	aprocess.setData(4000, 10);
	assertEquals(400,aprocess.calcuTax());
}

//@Test
//public void testCheckdataSuccess()
//{
//	assertTrue(aprocess.checkData());
//}

}
