package com.stackroute.SampleJacoco;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class ProductSetServiceTest {

	private static final String MESSAGE_ADD = "couldn't add product to ProductSetService ";
	private static final String MESSAGE_EXP = "Should throw exception when invalid price is given ";
	private static final String MESSAGE_REP = "change product name ";
	private static final String MESSAGE_HIGH = "get high price ";
	
	private ProductSetService ProductSetService;
	
	
	
	@BeforeEach
    public void setUp() throws InvalidPriceException {
		ProductSetService = new ProductSetService();
		
	}
	
	@Test
	public void addProductToSet() throws InvalidPriceException
	{
		Assertions.assertEquals(true,ProductSetService.addProductToSet(2, "keyboard", 20000),MESSAGE_ADD);
	}
	
	@Test
    public void givenWrongPriceThenReturnAnException() {
        assertThrows(InvalidPriceException.class, () -> ProductSetService.addProductToSet(1, "keyboard", -20000),MESSAGE_EXP);
	}
	
	@Test
    public void givenReplaceProductName() throws InvalidPriceException {
		ProductSetService.addProductToSet(1, "fan", 1000);
		Product pro = new Product(1, "UPS", 1000);
		Assertions.assertEquals(pro,ProductSetService.replaceProductName("fan", "UPS"),MESSAGE_REP);
	}
	
	@Test
    public void givenInvalidProductNameReplaceProductName() throws InvalidPriceException {
		ProductSetService.addProductToSet(1, "fan", 1000);
		Assertions.assertEquals(null,ProductSetService.replaceProductName("Mobile", "UPS"),MESSAGE_REP);
	}
	
	@Test
    public void givenListEmptyProductNameReplaceProductName() throws InvalidPriceException {
		Assertions.assertEquals(null,ProductSetService.replaceProductName("Mobile", "UPS"),MESSAGE_REP);
	}
	
	
	@Test
    public void getProductWithHighestPrice() throws InvalidPriceException {
		ProductSetService.addProductToSet(1, "fan", 1000);
		ProductSetService.addProductToSet(2, "mobile", 500);
		Product Product = new Product(1, "fan", 1000);
		Assertions.assertEquals(Product,ProductSetService.getProductWithHighestPrice(),MESSAGE_HIGH);
	}
     
	@Test
    public void removeProductWithPriceHigherThanFiveThousand() throws InvalidPriceException {
		ProductSetService.addProductToSet(1, "fan", 6000);
		Set<Product> productSet = new HashSet<>();
		Assertions.assertEquals(productSet,ProductSetService.removeProductWithPriceHigherThanFiveThousand());
	}
	
	@Test
    public void getProductIdList() throws InvalidPriceException {
		ProductSetService.addProductToSet(1, "fan", 6000);
		List<Integer> productSet = new ArrayList<>();
		productSet.add(1);
		Product product = new Product(1, "fan", 6000);
		Assertions.assertEquals(productSet,ProductSetService.getProductIdList());
	}
}
