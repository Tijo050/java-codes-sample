package com.stackroute.SampleJacoco;
import java.io.IOException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ProductTest {
	private static final String MESSAGE_GET = "Product properties not getting properly by constructor";
	private static final String MESSAGE_SET = "Product properties not set properly by constructor";
	private static final String MESSAGE_COMPARE = "Product returnns wrong data on comaring";
	private static final String MESSAGE_OBJ = "Product Object comparison returns wrong data";
	
	
	private Product product;
	
	@BeforeEach
    public void setUp() throws InvalidPriceException {
		product = new Product(1, "pen", 1000);
	}
	
	@AfterEach
    public void tearDown() {
		product = null;
	}
	
	 @Test
	public void givenobjectpropertiesareget() throws IOException {
		 
	Assertions.assertEquals(1, product.getProductId(), MESSAGE_GET);
	Assertions.assertEquals("pen", product.getProductName(), MESSAGE_GET);
	Assertions.assertEquals(1000, product.getPrice(), MESSAGE_GET);
	}
	 
	@Test
	public void givenObjectPropertySet() throws IOException{
		product.setProductName("Laptop");
		Assertions.assertEquals("Laptop", product.getProductName(), MESSAGE_SET);
		
	}
	
	@Test
	public void givenValidValueToCompare() throws InvalidPriceException
	{
		Product product2 = new Product(4, "keyboard", 500);
		Assertions.assertEquals(500,product.compareTo(product2),MESSAGE_COMPARE);
	}
	
	@Test
	public void objectComparisonValid() throws InvalidPriceException
	{
		Product product2 = new Product(4, "keyboard", 500);
		Assertions.assertEquals(false, product.equals(product2),MESSAGE_OBJ);
	}
	
	@Test
	public void objectComparisonNonValid() throws InvalidPriceException
	{
		Product product2 = new Product(1, "pen", 1000);
		Assertions.assertEquals(true, product.equals(product2),MESSAGE_OBJ);
	}  

}
