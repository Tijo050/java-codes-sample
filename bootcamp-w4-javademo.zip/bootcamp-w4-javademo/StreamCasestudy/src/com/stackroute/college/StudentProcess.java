package com.stackroute.college;

import java.util.Scanner;

import com.stackroute.college.model.Student;
import com.stackroute.college.service.StudentServiceImpl;
import com.stackroute.college.service.iStudentservice;


public class StudentProcess {

	public static void main(String[] args) throws Exception {
 
	//	iStudentservice service=new StudentServiceImpl("newcollege.dat");
		
	 
	String ch="y";
		while (ch.equals("y"))
		{
			System.out.println("1- view, 2 add");
			
			Scanner scan=new Scanner(System.in);
			int choice=scan.nextInt();
		switch(choice)
		{
		case 1:
			iStudentservice service1=new StudentServiceImpl("newcollege.dat",1);
			service1.showStudentdetails();
			break;
		case 2:
			iStudentservice service2=new StudentServiceImpl("newcollege.dat",2);
			System.out.println("provide rollno and name");
			Student studentnew=new Student(scan.nextInt(),scan.next());
			service2.addStudentData(studentnew);
		
		 }//switch

		} // while
		
	} //main
}
	
