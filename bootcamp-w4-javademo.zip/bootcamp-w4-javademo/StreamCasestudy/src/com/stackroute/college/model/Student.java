package com.stackroute.college.model;

import java.io.Serializable;

public class Student implements Serializable{
int rollno;
String studentName;
public int getRollno() {
	return rollno;
}
public void setRollno(int rollno) {
	this.rollno = rollno;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public Student() {}
public Student(int rno,String sname)
{
	this.rollno=rno;
	this.studentName=sname;
}
public String toString()
{
	return "Roll no "  + rollno + "studnet name " + studentName;
	
}

}
