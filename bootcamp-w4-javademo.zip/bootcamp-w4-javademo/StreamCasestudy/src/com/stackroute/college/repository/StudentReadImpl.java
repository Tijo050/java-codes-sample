package com.stackroute.college.repository;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import com.stackroute.college.model.Student;

public class StudentReadImpl implements iStudentRead{

	  List<Student> students=new ArrayList<Student>();
	  FileInputStream filein;
	  ObjectInputStream objinput;
	 
	 public StudentReadImpl(String filename) throws Exception
	 {
		filein =new FileInputStream(filename);
		objinput=new ObjectInputStream(filein);
		 
		 
	 }
	
	@Override
	public List<Student> getStudentData() throws Exception {

try
{
	//filein =new FileInputStream(filename);

	students= (List<Student>)objinput.readObject();
	
}
catch(Exception e)

{
	System.out.println("exception " + e);
}

finally
{
	objinput.close();
}
System.out.println("inside list" + students);
		return students;
	}

	
	
}
