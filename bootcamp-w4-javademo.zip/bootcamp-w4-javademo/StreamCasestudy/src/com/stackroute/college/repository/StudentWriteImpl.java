package com.stackroute.college.repository;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.stackroute.college.model.Student;

public class StudentWriteImpl implements iStudentWrite {

	List<Student> studentlist=new ArrayList<Student>();
	ObjectOutputStream objectout;
	
	List<Student> getData(String filename)
	{
		List<Student> resultdata=new ArrayList<Student>();
		iStudentRead studentread;
		try
		{
		studentread=new StudentReadImpl(filename);
		resultdata=studentread.getStudentData();
		}
		catch(Exception e)
		{
			studentread=null;
		}  	
		
		return resultdata;
	}
	
	public StudentWriteImpl(String filename) throws Exception
	{
		studentlist=getData(filename);
		
		FileOutputStream fileout=new FileOutputStream(filename);
		
		
		objectout=new ObjectOutputStream(fileout);
		
		
		// if file not exist ?
		
	}
	@Override
	public void add(Student studentnew) throws Exception {
 		
	try
	{
			studentlist.add(studentnew);
			objectout.writeObject(studentlist);
			
	}
	catch(Exception e)
	{
		System.out.println("error " + e.getMessage());
	}
	finally
	{
		objectout.close();
		System.out.println("file closed");
	}
	}

	
}
