package com.stackroute.college.repository;

import java.util.List;

import com.stackroute.college.model.Student;

public interface iStudentRead {
	List<Student> getStudentData() throws Exception;
	
	

}
