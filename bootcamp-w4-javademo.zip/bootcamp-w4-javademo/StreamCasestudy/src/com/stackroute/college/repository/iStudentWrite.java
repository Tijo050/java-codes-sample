package com.stackroute.college.repository;

import com.stackroute.college.model.Student;

public interface iStudentWrite {

	  void add(Student student) throws Exception;
}
