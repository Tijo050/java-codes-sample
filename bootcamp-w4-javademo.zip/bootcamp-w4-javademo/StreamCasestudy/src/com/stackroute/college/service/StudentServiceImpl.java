package com.stackroute.college.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.stackroute.college.model.Student;
import com.stackroute.college.repository.StudentReadImpl;
import com.stackroute.college.repository.StudentWriteImpl;
import com.stackroute.college.repository.iStudentRead;
import com.stackroute.college.repository.iStudentWrite;

public class StudentServiceImpl implements iStudentservice{

	iStudentRead sread;
	iStudentWrite swrite;
	public StudentServiceImpl(String filename,int choice)  throws Exception
	{ 
		if(choice==2)
		swrite=new StudentWriteImpl(filename);
		else if(choice==1)
		{
		 try
		 {
		sread=new StudentReadImpl(filename);
	
		 }
	catch(Exception e)
		 {
		   System.out.println("file not exist" + e.getMessage());
			sread=null; 
		 }
		}
	}
	
	
	@Override
	public List<Student> showStudentdetails() throws Exception {
		 if(sread!=null)
		return sread.getStudentData();
		 else
			 return null;
	}

	@Override
	public void addStudentData(Student studentnew) throws Exception {
	
		swrite.add(studentnew);
		 System.out.println("added");
		 
	}

}
