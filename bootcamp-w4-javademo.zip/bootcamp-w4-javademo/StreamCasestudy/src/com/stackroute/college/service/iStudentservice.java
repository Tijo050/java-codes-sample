package com.stackroute.college.service;

import java.util.List;

import com.stackroute.college.model.Student;

public interface iStudentservice {
   List<Student> showStudentdetails() throws Exception;
   void addStudentData(Student studentnew) throws Exception;
}
