package com.stackroute.ThreadConcurrency;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

class ForkRecursive extends RecursiveAction
{
	long filesize=0;
	 public ForkRecursive(long fsize)
	 {
		 this.filesize=fsize;
	 }

	@Override
	protected void compute() {
	 
		if(this.filesize>4)
		{
			  System.out.println( " Split the work " + this.filesize);
			  
			  List<ForkRecursive> subtasks=new ArrayList<ForkRecursive>();
			  
			List<ForkRecursive> generatedsub=generateSubtask();
			
			subtasks.addAll(generatedsub);
			
			for(ForkRecursive fr : subtasks)
			{
				fr.fork();
			}
			
		}
		else
		{
			System.out.println("Wrote inside file" + this.filesize);
		}
			
	}
	
	List<ForkRecursive> generateSubtask()
	{
		List<ForkRecursive> results=new ArrayList<ForkRecursive>();
		
		ForkRecursive task1=new ForkRecursive(this.filesize/2);
		ForkRecursive task2=new ForkRecursive(this.filesize/2);
		
		results.add(task1);
		results.add(task2);
		return results;
	}
	
}



public class ExampleForkJoinAction {

	public static void main(String[] args) {
	 
		ForkJoinPool fjpool=new ForkJoinPool(6);
		ForkRecursive forkactionobj=new ForkRecursive(18);

		 fjpool.invoke(forkactionobj);

	}

}
