package com.stackroute.ThreadConcurrency;

 

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

class MultiNum extends RecursiveTask<Long>
{
	long load=0;
	public MultiNum(long n)
	{
		load=n;
	}
	
@Override
	protected Long compute() {
		 if(this.load>5)
		 {
			 System.out.println( " splitting load to subtask " + load);
			 List<MultiNum> subtasks=new ArrayList<MultiNum>();
			 
			 subtasks.addAll(generateSubtask());
			 
			 for(MultiNum multiobj : subtasks) 
			 {
				 multiobj.fork();  // allocates thread and  invoke  compute 
				 
				 		
				 
			 }
			 
			 long result=0;
			 
			 for(MultiNum mulobj : subtasks)
			 {
				result+= mulobj.join();  // subtask will be returned to parent task
			 }
			 return result;
		 }
		 else
		 {
			  System.out.println ( "inside calculation task " +  this.load) ;
			  return load * 3;
		 }
	
	}
	
	private List<MultiNum> generateSubtask()
	{
		List<MultiNum> subtasklist=new ArrayList<MultiNum>();
		
		MultiNum task1=new MultiNum(load/2);
		MultiNum task2=new MultiNum(load/2);
		
		subtasklist.add(task1);
		subtasklist.add(task2);
		return subtasklist;
	}
	
}

public class ExampleForkJoinTask {

	public static void main(String[] args) {
	
		ForkJoinPool forkpool =new ForkJoinPool(4);
   MultiNum multinum=new MultiNum(16);
   
    long result= forkpool.invoke(multinum);
    System.out.println ("Final result " + result);
	}

}
