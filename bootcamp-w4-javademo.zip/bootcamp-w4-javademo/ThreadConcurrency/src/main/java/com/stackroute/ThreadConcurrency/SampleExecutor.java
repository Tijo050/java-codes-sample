package com.stackroute.ThreadConcurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Company implements Runnable
{
	String company;
  String deptName;
	  Company(String company,String dname)
	  {
		  this.company=company;
		  this.deptName=dname;
	  }
  
	public void run() {
		
		for (int i=1;i<=5;i++)
		{
			try 
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{}
			processWork();
		}
	}
	
	
	public synchronized void processWork()
	{
		if(deptName.equals("HR"))
			System.out.println("Calling recruitment process");
		else if (deptName.equals("Finance"))
			System.out.println("Payroll processing");
		else if(deptName.equals("Sales"))
			System.out.println("calling sales and marketting transaction");
	}
	
}


public class SampleExecutor {

	public static void main(String[] args) {
		
		Company compobj1=new Company("Stackroute","HR");
		Company compobj2=new Company("Stackroute","Finance");
		Company compobj3=new Company("Stackroute","Sales");
		
//		Thread t1=new Thread(compobj1);
//		t1.start();
		
		ExecutorService executor=Executors.newFixedThreadPool(3);
		try
		{
			executor.execute(compobj1);
			executor.execute(compobj2);
			executor.execute(compobj3);
		}
		catch(Exception e)
		{	
			
			System.out.println(e);
		}
		finally
		{
			executor.shutdown();
		}
			
	}

}
