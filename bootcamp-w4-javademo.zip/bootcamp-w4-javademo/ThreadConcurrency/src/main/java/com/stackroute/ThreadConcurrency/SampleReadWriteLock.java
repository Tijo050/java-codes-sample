package com.stackroute.ThreadConcurrency;

import java.util.Random;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class GenerateData extends Thread
{
	static ReentrantReadWriteLock readwriteobj=new ReentrantReadWriteLock();
	int number;
	public void run()
	{
		
		 try {
			 writeNumber();
			Thread.sleep(2000);
			 readNumber();
		} 
		 catch (Exception e) {
		 	 
		            }
		
	}
	
   void writeNumber()
   {
	   try
	   {
		   readwriteobj.writeLock().lock();
		   
		    number=new Random().nextInt(10);
		  System.out.println(Thread.currentThread().getName() + " am writing " + number); 
	  }
	   catch(Exception e)
	   {		   
	   }
	   finally
	   {
		   System.out.println("Write operation is over");
	   }
	   readwriteobj.writeLock().unlock();
   } //writenumber
	   void readNumber()
   {
	   try
	   {
		   readwriteobj.readLock().lock();
		   System.out.println(Thread.currentThread().getName() + " is reading "  + number);
		   
	   }
	   catch(Exception e)
	   {	   
	   }
	   finally
	   {
		   System.out.println("Read Operation is over");
	   }
	   readwriteobj.readLock().unlock();
   }
   
	
}




public class SampleReadWriteLock {

	public static void main(String[] args) {

		GenerateData genobj1=new GenerateData();
		genobj1.start();
		GenerateData genobj2=new GenerateData();
		genobj2.start();
		
		GenerateData genobj3=new GenerateData();
		genobj3.start();
	}

}
