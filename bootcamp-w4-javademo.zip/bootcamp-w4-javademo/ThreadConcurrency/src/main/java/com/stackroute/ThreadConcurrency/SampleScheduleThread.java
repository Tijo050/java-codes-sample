package com.stackroute.ThreadConcurrency;

import java.time.LocalTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

class Training implements Runnable
{
	String topic;
	
	Training(String topic)
	{
		this.topic=topic;
	}

	public void run() {

		System.out.println("Exercise to be given " + topic + " time " + LocalTime.now());
	}
	
}

class Assessment implements Runnable
{

	public void run() 
	{
System.out.println("Assessment given " + LocalTime.now());		
	}
	
}


public class SampleScheduleThread {

	public static void main(String[] args) {
	 
		ScheduledThreadPoolExecutor scheduleobj= (ScheduledThreadPoolExecutor) Executors.newScheduledThreadPool(3);

		Training trainjava=new Training("Java8");
		Training trainui=new Training("HTML5");
		Assessment assobj=new Assessment();
		
		scheduleobj.scheduleWithFixedDelay(trainjava, 1, 5, TimeUnit.SECONDS);
		scheduleobj.scheduleWithFixedDelay(trainui, 5, 10, TimeUnit.SECONDS);
		scheduleobj.scheduleWithFixedDelay(assobj, 10, 15,TimeUnit.SECONDS);
		
		
	}

}
