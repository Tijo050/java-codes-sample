package com.stackroute.ThreadConcurrency;

 

class User implements Runnable
{
	 volatile int choice;
	
	public int count=0;
	
	void setChoice(int c)
	{
		choice=c;
	
	}
	public void run()
	{
		  while(choice==0)
		  {
			  count++;
			  
		  }
		  
		System.out.println("current choice" + choice +  "user Count" + count);
	}
}

public class VolatileSample {

	public static void main(String[] args)  throws Exception{
		
		System.out.println("Before setting choice");
	 User user1=new User();
	 new Thread(user1).start();
	 Thread.sleep(1000);
	 
	System.out.println("After setting choice"+user1.count);
	
user1.setChoice(1);




	}

}
