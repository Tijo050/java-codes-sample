package DigitalCaseStudy;

import DigitalCaseStudy.service.GameProcessImpl;
import DigitalCaseStudy.service.Inter_validate;
import DigitalCaseStudy.service.UserImpl;
import DigitalCaseStudy.service.inter_gameprocess;

public class DigitalGameOnline {

	public static void main(String[] args) {

		Inter_validate userservice=new UserImpl();
		inter_gameprocess gameservice=new GameProcessImpl();
		
		
		
	}

}
