package DigitalCaseStudy.exception;

public class InvalidAdminuserException  extends Exception{

	public InvalidAdminuserException()
	{
		
	}
}
