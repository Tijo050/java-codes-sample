package DigitalCaseStudy.model;

public class Game {

	String gameName,gameAuthor;
	int price;

	Game(){}
	public Game(String gname,String auth,int pri)
	{
		this.gameName=gname;
		this.gameAuthor=auth;
		this.price=pri;
		
	}
	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public String getGameAuthor() {
		return gameAuthor;
	}

	public void setGameAuthor(String gameAuthor) {
		this.gameAuthor = gameAuthor;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
}
