package DigitalCaseStudy.model;

public class User {

	String userid , password, usertype ;
public User() {}
public User(String uid,String pwd,String utype)
{
	userid=uid;
	this.password=pwd;
	this.usertype=utype;
}
	
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	
}
