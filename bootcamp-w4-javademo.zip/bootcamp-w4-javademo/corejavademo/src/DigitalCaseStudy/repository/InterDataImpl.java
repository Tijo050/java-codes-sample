package DigitalCaseStudy.repository;

import java.util.ArrayList;
import java.util.List;

import DigitalCaseStudy.model.Game;


public class InterDataImpl implements inter_data {

	List<Game> gamelist=new ArrayList();
 
	public List<Game> getGameList() {
		 
	Game game1=new Game("Tubix","Danny",300);
	
	Game game2=new Game("FreshFood","Ram",450);
	
	Game game3=new Game("Batman","Kate",400);
	
	gamelist.add(game1);
	gamelist.add(game2);
	gamelist.add(game3);
	 	
		
		return gamelist;
	}

	
	
}
