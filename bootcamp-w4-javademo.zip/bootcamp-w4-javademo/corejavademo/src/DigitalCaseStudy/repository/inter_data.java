package DigitalCaseStudy.repository;

//import java.util.ArrayList;
import java.util.List;

import DigitalCaseStudy.model.Game;

public interface inter_data {
	
	
	
//	List<Game> gamelist=new ArrayList<Game>();
	
		List<Game> getGameList();

}
