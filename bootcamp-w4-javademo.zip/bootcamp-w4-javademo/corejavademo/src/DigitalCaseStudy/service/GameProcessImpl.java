package DigitalCaseStudy.service;

import java.util.List;

import DigitalCaseStudy.model.Game;
import DigitalCaseStudy.repository.InterDataImpl;
import DigitalCaseStudy.repository.inter_data;

public class GameProcessImpl implements inter_gameprocess {

	inter_data datarepo;
	List<Game> games;
	
	public GameProcessImpl()
	{
		datarepo=new InterDataImpl();
		games=datarepo.getGameList();
	}
	
	
	@Override
	public String authorSearch(String sear) {
		
		Game gameresult=null;
		 for(Game gameobj : games)
		 {
			 if (gameobj.getGameAuthor().equals(sear))
				 gameresult=gameobj;
				 
		 }
		
		 if(gameresult!=null)
		return gameresult.getGameName();
		 else
			 return "Not Found";
	}

	@Override
	public String gameSearch(String game1) {
		Game gameresult=null;
				for(Game gameobj : games)
				{
					if(gameobj.getGameName().equals(game1))
						gameresult=gameobj;
				}
		
				 if(gameresult!=null)
						return gameresult.getGameAuthor();
						 else
							 return "Not Found";
	}

	@Override
	public List<Game> viewAll() {
		// TODO Auto-generated method stub
		return games;
	}

}
