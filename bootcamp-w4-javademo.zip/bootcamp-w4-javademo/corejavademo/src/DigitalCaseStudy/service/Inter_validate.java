package DigitalCaseStudy.service;

import DigitalCaseStudy.exception.InvalidAdminuserException;
import DigitalCaseStudy.model.User;

public interface Inter_validate {

	  boolean IsAuthenticated(String userid,String password,String usertype) throws InvalidAdminuserException ;
	  void log();
	User addUser(String userid,String password,String usertype);
	  
}
