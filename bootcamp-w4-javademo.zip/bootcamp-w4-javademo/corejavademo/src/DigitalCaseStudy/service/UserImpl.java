package DigitalCaseStudy.service;

import DigitalCaseStudy.exception.InvalidAdminuserException;
import DigitalCaseStudy.model.User;

public class UserImpl implements Inter_validate{

	@Override
	public boolean IsAuthenticated(String userid, String password, String usertype) throws InvalidAdminuserException
	{
	 if(usertype.equals("Admin") )
	 {
		  if(!password.equals("PASSWORD"))
			  throw new InvalidAdminuserException();
	 }
		return false;
	}

	@Override
	public void log() {
		System.out.println("Some user logged in");
		
	}

	@Override
	public User addUser(String userid, String password, String usertype) {
		User userobj=new User(userid,password,usertype);
		return userobj;
	}

}
