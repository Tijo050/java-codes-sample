package DigitalCaseStudy.service;

import java.util.List;

import DigitalCaseStudy.model.Game;

public interface inter_gameprocess {

	String authorSearch(String sear);
	String gameSearch(String bk);
	List<Game> viewAll();
}
