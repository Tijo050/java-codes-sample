package employeerepomodel;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import employeerepomodel.exception.PersonAlreadyExistException;
import employeerepomodel.exception.PersonNotFoundException;
import employeerepomodel.model.Person;
import employeerepomodel.service.PersonService;
import employeerepomodel.service.iPersonserve;

public class PersonSampleMain {

	public static void main(String[] args) throws IOException {

		iPersonserve personservice=new PersonService();
		
		char ch='y';
		
		while(ch=='y')
		{
		System.out.println("1-viewallperson, 2- add new person, 3-delete , 4 -exit");
		Scanner scan=new Scanner(System.in);
		int choice=scan.nextInt();
	
			
		switch(choice)
		{
		
		case 1:
				
		List<Person> perlist=personservice.viewPersondetails();
		 for(Person pobj : perlist)
			 System.out.println(pobj);
		 break;
		 
		case 2:
			Person pernew=new Person(90,"Dan",30);
			try
			{
			personservice.addPersondetail(pernew);
			System.out.println("Added");
			}
			catch(PersonAlreadyExistException e)
			{
				System.out.println(e.getMessage());
			}
			break;
		case 3:
			try
			{
			personservice.removePerson(20);
			System.out.println("Person deleted");
			}
			catch(PersonNotFoundException e)
			{
				System.out.println(e.getMessage());
			}
			break;
		default:
			break;
		}
			System.out.println("Do you want to continue y/n");
			ch=(char) System.in.read();
		
		}

	}

}
