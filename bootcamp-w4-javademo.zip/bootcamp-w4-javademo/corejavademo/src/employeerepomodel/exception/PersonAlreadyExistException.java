package employeerepomodel.exception;

public class PersonAlreadyExistException  extends Exception{
	
	public PersonAlreadyExistException(String msg)
	{
		super(msg);
	}

}
