package employeerepomodel.model;

//POJO 

public class Person {

	 int personid;
	 String personName;
	 int age;
	 public Person(int pid,String pname,int age)
	 {
		 this.personid=pid;
		 this.personName=pname;
		 this.age=age;
	 }
	public int getPersonid() {
		return personid;
	}
	public void setPersonid(int personid) {
		this.personid = personid;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	 
	public String toString()
	{
		return " Name " + personName +  "Age is "  + age;
	}
}
