package employeerepomodel.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import employeerepomodel.model.Person;

public class PersonRepo implements iPersonRepo {

	static List<Person> personlist=new ArrayList<Person> ();
	
	public static List<Person> getInitialdata()
	{
		Person person1=new Person(10,"Sudha",29);
		Person person2=new Person(20,"Manju",19);
		Person person3=new Person(30,"Varun",24);
		
		personlist.add(person1);
		personlist.add(person2);
		personlist.add(person3);
		
		return personlist;
	};
	
	
	@Override
	public void add(Person person) {
		personlist.add(person);
	}

	@Override
	public List<Person> getAll() {
		// TODO Auto-generated method stub
		return personlist;
	}

	@Override
	public boolean delete(Person object) {
		personlist.remove(object);
		return false;
	}

	@Override
	public void modify(Person person) {

		  
	}

	@Override
	public Person findbyId(int personid) {
		Person personres=null;
		ListIterator iterateobj=personlist.listIterator();
		while(iterateobj.hasNext())
		{
			Person pobj=(Person)iterateobj.next();
			if(pobj.getPersonid()==personid)
				personres=pobj;
		}
		return personres;
	}

	
}
