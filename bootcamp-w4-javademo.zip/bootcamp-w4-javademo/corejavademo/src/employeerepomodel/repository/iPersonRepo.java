package employeerepomodel.repository;

import java.util.List;

import employeerepomodel.model.Person;

public interface iPersonRepo {

	void add(Person person) ;
   List<Person> getAll();
   boolean delete(Person obj);
   void modify(Person person);
   Person findbyId(int personid); 
	
}
