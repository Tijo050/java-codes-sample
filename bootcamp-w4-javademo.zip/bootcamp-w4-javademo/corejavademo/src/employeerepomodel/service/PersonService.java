package employeerepomodel.service;

import java.util.List;

import employeerepomodel.exception.PersonAlreadyExistException;
import employeerepomodel.exception.PersonNotFoundException;
import employeerepomodel.model.Person;
import employeerepomodel.repository.PersonRepo;
import employeerepomodel.repository.iPersonRepo;

public class PersonService implements iPersonserve {

	List<Person> persondata=PersonRepo.getInitialdata();
	iPersonRepo ipersonrepo;
	
	public PersonService()
	{
		ipersonrepo=new PersonRepo();
	}
	
	@Override
	public void addPersondetail(Person personnew) throws PersonAlreadyExistException {
	 
	 
		Person personres=ipersonrepo.findbyId(personnew.getPersonid());
		if(personres==null)
		{
			ipersonrepo.add(personnew);
			
		}
		
		else
			throw new PersonAlreadyExistException("id is duplicate");
		
		
	}

	@Override
	public void removePerson(int pid) throws PersonNotFoundException {
		 
		Person persontodel = findPerson(pid);
		
		if(persontodel==null)
			throw new PersonNotFoundException("Id doesnt exist");
		else
			ipersonrepo.delete(persontodel);
		
	}

	@Override
	public List<Person> viewPersondetails() {
	
		return persondata;
	}

	@Override
	public void modifyPerson(Person person) throws PersonNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Person findPerson(int pid) throws PersonNotFoundException {
     
	Person personfound=null;
	personfound=ipersonrepo.findbyId(pid);
	return personfound;
	
	
	}

}
