package employeerepomodel.service;

import java.util.List;

import employeerepomodel.exception.PersonAlreadyExistException;
import employeerepomodel.exception.PersonNotFoundException;
import employeerepomodel.model.Person;

public interface iPersonserve {

	void addPersondetail(Person person) throws PersonAlreadyExistException;
	void removePerson(int pid) throws PersonNotFoundException;
	List<Person> viewPersondetails();
	void modifyPerson(Person person) throws PersonNotFoundException;
	Person findPerson(int pid) throws PersonNotFoundException;
	
	
}
