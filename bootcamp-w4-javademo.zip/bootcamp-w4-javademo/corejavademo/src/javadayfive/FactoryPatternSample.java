package javadayfive;

interface iLearning
{
	void processTest();
}

class College implements iLearning
{

	@Override
	public void processTest() {
	System.out.println("semester exams processing");
		
	}
	
}
class School implements iLearning
{

	@Override
	public void processTest() {
		System.out.println("Annual Exams going on");
		
	}
	
}

interface iLearnFactory
{
	public iLearning getTestType(String s);
}

class TestFactoryImpl implements iLearnFactory
{

	 
	public iLearning getTestType(String s) {
	
		if(s.equals("School"))
			return new School();
		else if (s.equals("College"))
			return new College();
		else
			return null;
	}
	
}

public class FactoryPatternSample {

	public static void main(String[] args) {

		iLearnFactory learnfact=new TestFactoryImpl();
		
		try {
		iLearning learnbase=learnfact.getTestType("School");
		
		learnbase.processTest();
		}
		catch(Exception e)
		{
			System.out.println("Invalid learner");
		}

	}

}
