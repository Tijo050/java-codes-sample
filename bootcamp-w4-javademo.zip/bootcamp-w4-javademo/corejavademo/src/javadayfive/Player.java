package javadayfive;

public class Player
{
	String pname;
	String country;
		Player(String pname,String cntry)
		{
			this.pname=pname;
			this.country=cntry;
		}
		public String toString()
		{
			return (" player " + pname + "Counry " + country);
		}
}