package javadayfive;

import java.util.ArrayList;
import java.util.List;

class CompanyProduct implements Cloneable
{
	int companyid;
	List<String> items=new ArrayList();
	public CompanyProduct() {}
	public CompanyProduct(List<String> itemlist)
	{
		this.items=itemlist;
	}
	public void baseItems()
	{
		items.add("Rin Powder");
		items.add("Cinthol Soap");
		items.add("Colgate Toothpaste");
		
	}
	public List<String> getItems()
	{
		return items;
	}
	public void addItem(String s)
	{
		items.add(s);
	}
	protected Object clone() throws CloneNotSupportedException
	{
	List<String> temp=new ArrayList<String>();
	for(String str : items)
	{ 
		 if(str.startsWith("C"))
		temp.add(str);
	}
	return new CompanyProduct(temp);
	}
} 



public class ProductPrototype {

	public static void main(String[] args) throws CloneNotSupportedException {
	
CompanyProduct basecompany=new CompanyProduct();		
basecompany.baseItems();

CompanyProduct southcompany= (CompanyProduct) basecompany.clone();

List<String> productdata=southcompany.getItems();
System.out.println("South branches" + productdata);
southcompany.addItem("Ponds");

 productdata=southcompany.getItems();
System.out.println("South branches" + productdata);
 


	}

}
