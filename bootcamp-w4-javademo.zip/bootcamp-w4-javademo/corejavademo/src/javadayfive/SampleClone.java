package javadayfive;

class Furniture  implements Cloneable
{
	String furtype;
	
	public Furniture(String ftype)
	{
		this.furtype=ftype;
	}
	
	
	public String getFurtype() {
		return furtype;
	}

	public void setFurtype(String furtype) {
		this.furtype = furtype;
	}

	protected Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
	public String toString()
	{
		return "Furniture type " + furtype;
	}
}

public class SampleClone {

	public static void main(String[] args) throws CloneNotSupportedException {
		 Furniture fur1=new Furniture("Bed");
		 Furniture fur2=(Furniture) fur1.clone();
		 
		  
System.out.println(fur1.hashCode());

System.out.println(fur2.hashCode());

System.out.println(fur1);

System.out.println(fur2);
		 
	}

}
