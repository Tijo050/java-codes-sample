package javadayfive;

import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

class Playercompare implements Comparator
{

	@Override
	public int compare(Object obj1, Object obj2) {
		Player play1=(Player)obj1;
		Player play2=(Player)obj2;
		return play1.pname.compareTo(play2.pname);
	}
}

public class SampleComparator {

	public static void main(String[] args) {
	 
Vector<Player> players=new Vector<Player>();

Player player3=new Player("Ray","US");
Player player1=new Player("Irfan","India");
Player player2=new Player("Mart","UK");
players.add(player1);
players.add(player2);
players.add(player3);

Collections.sort(players,new Playercompare());

for(Player play : players)
	System.out.println(play);


	}

}
