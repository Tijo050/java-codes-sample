package javadayfive;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SampleMap {

	public static void main(String[] args)
	{
//		Map mapdata=new HashMap();
//		mapdata.put("e1", "Delhi");
//		mapdata.put("c1","Chennai");
//		mapdata.put("b1","Banglore");
		
		
		Map<String,Player> mapdata=new HashMap<String,Player>();
		
		Player player3=new Player("Ray","US");
		Player player1=new Player("Irfan","India");
		Player player2=new Player("Mart","UK");
		
		mapdata.put("p1",player1);
		mapdata.put("p2",player2);
		mapdata.put("p3",player3);
		
		
		
			Collection coll=mapdata.values();
			Set keys=mapdata.keySet();
			
	   for (Object obj : keys)
	   {
		    if(obj.toString().equals("p3"))
		   System.out.println( mapdata.get(obj));
	   }
		
	  
	}

}
