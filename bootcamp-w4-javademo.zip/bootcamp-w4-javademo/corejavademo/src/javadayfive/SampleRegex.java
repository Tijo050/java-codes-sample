package javadayfive;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SampleRegex {

	public static void main(String[] args) {
	
		String name="aaaaaaaaaa";
		
	//	Pattern pattn=Pattern.compile("[aA][a-z][a-z][a-z]d");
		
		Pattern pattn=Pattern.compile("a*");

		Matcher matchobj=pattn.matcher(name);
		
		if(matchobj.matches())
			System.out.println("Name is valid");
		else
			System.out.println("Invalid name");
		
	System.out.println("Enter landline");	
		String landline="080-246165";
		
		
//		
//		Scanner scan=new Scanner(System.in);
//		
//		landline=scan.next();
//		
//		Pattern patphone=Pattern.compile("0[1-9][0-9]-\\d{6}");
//		
//		Matcher matchobj2= patphone.matcher(landline);
//		
//		if(matchobj2.matches())
//			System.out.println("landline is valid");
//		else
//			System.out.println("invalid");
		
		
		String sentence="World is Beautiful. World is lovely";
		
		Pattern mypat=Pattern.compile("World");
		
		Matcher matchobj3=mypat.matcher(sentence);
		
	String output=matchobj3.replaceAll("Home");
	
	System.out.println(output);
	
	String today="12-15-2021";
	
	Pattern patdate=Pattern.compile("(0?[1-9]|1[012])[\\/\\-](0?[1-9]|[12][0-9]|3[01])[\\/\\-]\\d{4}");
	
	Matcher matdt=patdate.matcher(today);
	
	if(matdt.matches())
		System.out.println("Valid date");
	else
		System.out.println("invalid dt");
	
	
	
	
	
	
	
	
	}

}


















