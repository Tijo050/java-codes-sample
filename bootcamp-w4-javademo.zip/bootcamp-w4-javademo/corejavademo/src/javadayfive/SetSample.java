package javadayfive;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

class Employee implements Comparable
{
	int empid;
	String ename;
	Employee(int eid,String name)
	{
		empid=eid;
		ename=name;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public int hashCode()
	{
		return empid;
	}
	
	public boolean equals(Object obj)
	{
		Employee enew=(Employee)obj;
		
    return (this.empid-enew.empid==0);
	}
	
	
	
	public String toString()
	{
		return "Emp id " + empid + " name " + ename;
	}
	@Override
	public int compareTo(Object objnext) {
		Employee enew=(Employee)objnext;
		
		return (enew.empid-this.empid);  
	}
	
}

public class SetSample {

	public static void main(String[] args) {
	 		
		Set myset=new TreeSet();
			myset.add("Red");
		myset.add("Blue");
		myset.add("Red");
		
		System.out.println(myset);
		Set<Employee> employees=new TreeSet<Employee>();
		
	 
		Employee emp1=new Employee(10,"Arun");
		Employee emp2=new Employee(20,"Banu");
		Employee emp3=new Employee(5,"Mary");
		Employee emp4=new Employee(15,"Ravi");
		
		
		
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);
		
		for(Employee emp : employees)
			System.out.println(emp);

	}

}
