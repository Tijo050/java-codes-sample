package javadayfour;

enum Days {
	SUN,MON ,TUE,WED,THU,FRI
}


public class EnumSample {

	public static void main(String[] args) {
	
		displayData(Days.SUN);

	}

	static void displayData(Days daysobj)
	{
		
		switch(daysobj)
		{
		case SUN:
			   System.out.println("Its holiday");
			   break;
		case MON:
				System.out.println("Best day of the week");
				break;
		default:
		         break;
		}
	}
	
}
