package javadayfour;

interface iEngine
{
	void startEngine();
}

class Car implements iEngine
{
   public void startEngine() {
		 System.out.println("Car engine started ....");
		
	}
}
class Bus implements iEngine
{
	   public void startEngine() {
			 System.out.println("Bus  started ....");
			
		}
}


interface iEngineFactory
{
	Car startCar();
	Bus startBus();
	
	void startBusModel();
	
}

class EngineFactoryAll implements iEngineFactory
{
Bus bus; 
	EngineFactoryAll()
	{
		bus=new Bus();
	}
	
	public Car startCar() {
		 
		return new Car();
	}

	public Bus startBus() {
		return new Bus();
	}
	public void startBusModel() 
	{
		bus.startEngine();
	}
	
	 	
}


public class FacadePatternSample {

	public static void main(String ar[])
	{
		iEngineFactory enginefact=new EngineFactoryAll();
		
		iEngine myengine=enginefact.startCar(); //factory pattern
		
		myengine.startEngine();
		
		myengine=enginefact.startBus(); //factory pattern
		
		myengine.startEngine();
		
		enginefact.startBusModel(); //facade pattern
		
	}
	
}
