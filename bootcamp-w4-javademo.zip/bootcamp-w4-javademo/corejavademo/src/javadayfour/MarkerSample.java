package javadayfour;

interface iData
{
	
}
class Student implements iData
{
	String studname;
	void display()
	{
		System.out.println("welcome studnet");
	}
}

class Employee implements iData
{
	String empid;
}



public class MarkerSample {

	public static void main(String[] args) {
    printData(new Student());
    //or
    printData(new Employee());
		 
	}
	static void  printData (iData idataobj)
	 {
		if(idataobj instanceof Student)
		{
			Student sobj=(Student)idataobj;
			sobj.display();
		}
		
		 System.out.println("This class is having some data to be printed");
	 }
}
