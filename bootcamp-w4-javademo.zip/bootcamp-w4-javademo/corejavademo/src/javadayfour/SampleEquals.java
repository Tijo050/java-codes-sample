package javadayfour;

class Tablet
{
	String tabletName;
	int price;
	String compostion;
	
	public Tablet(String tabname,int price,String composition)
	{
		this.tabletName=tabname;
		this.price=price;
		this.compostion=composition;
	}
	
	
	public String getCompostion() {
		return compostion;
	}

	public void setCompostion(String compostion) {
		this.compostion = compostion;
	}


	
	public String getTabletName() {
		return tabletName;
	}
	public void setTabletName(String tabletName) {
		this.tabletName = tabletName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
		
		
	}

	
 public int hashCode()
 {
	return this.compostion.length(); 
 }
 
 
public boolean equals(Object obj)
{
	Tablet tabletnew=(Tablet) obj;
	if(this.compostion.equals(tabletnew.compostion))
		return true;
	else
		return false;
	
}

	
	
}


public class SampleEquals {

	public static void main(String[] args) {
	
		Tablet tablet1=new Tablet("Crocin",12,"h2o-12%");
		Tablet tablet2=new Tablet("Paracetemol",15,"h2o-12%");
		System.out.println(tablet1.hashCode());
		System.out.println(tablet2.hashCode());
		
		if (tablet1.equals(tablet2))
			System.out.println("Both are same. Anything can be taken");
		else
			System.out.println("Both are differnt table. consult doctor");
		

	}

}
