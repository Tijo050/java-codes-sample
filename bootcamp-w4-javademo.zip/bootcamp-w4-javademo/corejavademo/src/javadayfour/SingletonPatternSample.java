package javadayfour;

class CompanyModel
{
	static String norms="CMM level5";
	
	static CompanyModel companymodelobj=new CompanyModel();
	
	private CompanyModel()
{
	
}
	static CompanyModel getCompanymodel()
	{
		return companymodelobj;
	}
	
	void displayType()
	{
		System.out.println("Model is " + norms);
	}
}

public class SingletonPatternSample {

	public static void main(String[] args) {
	 
		CompanyModel companyobj1=CompanyModel.getCompanymodel();
		companyobj1.norms="CMM level4";
		companyobj1.displayType();
		
		
		CompanyModel companyobj2=CompanyModel.getCompanymodel();
		
		companyobj2.displayType();
		
	}

}
