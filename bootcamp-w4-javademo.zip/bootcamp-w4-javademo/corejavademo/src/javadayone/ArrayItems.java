package javadayone;

import java.util.Scanner;

public class ArrayItems {

	public static void main(String[] args) {
     
		//int[] tickets= {12,23,45,24,45,24};
		
	int[]	tickets=new int[5];
		
		
		Scanner scanobj=new Scanner(System.in);
		
		for(int i=0;i<=4;i++)
		tickets[i]=scanobj.nextInt();
		
		int count=0;
		
		do 
			{
			   if(tickets[count]%8==0)
			     System.out.println("lower berth");
			   else
				   System.out.println("Lower Berth not avaialble");
			count++;
			}while (count<5);
		
		
	}

}
