package javadayone;

import java.util.Scanner;

public class BankProcess {

	public static void main(String[] args) {
 
		Scanner scanobj=new Scanner(System.in);
		
		System.out.println("1- integerclass, 2-Float , 3-math functions , 4- exit");
		System.out.println("Enter your choice");
	
		
		int year1=2020, year2=2000;
		
		int number=243;
		Integer MaturityYear=new Integer(2015);
		
		
	//	int year=MaturityYear.intValue(); internally
		int year=MaturityYear; // auto unboxing
		
		
		
		// MaturityYear = new Integer(number) - internally
		MaturityYear=number;  // auto boxing
		
//		
//		MaturityYear.
		
		//number is a primitive data variable, MaturityYear is a object
			
		float baseAmt=2500.45f;
		
		
		float matBonus=100.50f;
		
		int choice=scanobj.nextInt();
//		System.out.println(choice);
	while (choice!=4)
	{
		switch(choice)
		{
		case 1:
			  int result=Integer.parseInt("334");
			  System.out.println("number is " + result);
			  break;
		case 2:
			  	System.out.println( "Overall amount" +  Float.sum(baseAmt, matBonus) );
			  	break;
		case 3:
			    int ans=Math.max(year1, year2);
			    System.out.println("Max year is " + ans);
			    break;
		case 4:
				break;
		default :
				break;
		
		
		}
		System.out.println("Want to continue : No - enter 4");
		choice=scanobj.nextInt();
		}
		
		
	}

}


/*
primitive  -- Wrapper classes

int		-- Integer
long	-- Long
float	-- Float
double  -- Double

*/