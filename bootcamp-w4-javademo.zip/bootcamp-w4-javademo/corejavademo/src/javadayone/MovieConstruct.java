package javadayone;

class Movie
{
	String movieName;
	String director;
	String hero;
	
 Movie()
	{
		
	}
//	public Movie()
//	{
//		movieName="Tomorrow never comes";
//		director="Andrews";
//		hero="Prabas";
//	}
	Movie(String mname,String direct,String hero)
	{
		this.movieName=mname;
		this.director=direct;
		this.hero=hero;
	}
	
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getHero() {
		return hero;
	}
	public void setHero(String hero) {
		this.hero = hero;
	}
	public String toString()
	{
		return " Movie " + movieName + " Hero "  + hero;
	}
}

public class MovieConstruct {

	public static void main(String[] args) {

	//	Movie movie;
	//	movie=new Movie();
		
//		System.out.println(movie);
		
		Movie movie2=new Movie("Goodmovie","goodirector","Raj");
		Movie movie3=new Movie("World","Wilson","Robin");
		Movie movie4=new Movie("Around the beat","Rane", "Mike");
		
		
		
  System.out.println(movie2);
  
  
	}

}
