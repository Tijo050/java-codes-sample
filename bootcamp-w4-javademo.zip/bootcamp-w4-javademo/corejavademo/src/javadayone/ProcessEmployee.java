package javadayone;

import java.util.Scanner;

class Employee 
{
	private   String empId;
	  private String empName;
	   private int salary;
	   
	   
	   
	public String getEmpId() {
		
		
		
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}

	   public String toString()
	   {
		   return "Emp id " + empId + " emp name " + empName + " salary " + salary;
	   }
	   
	
}


public class ProcessEmployee {

	public static void main(String[] args) {
		
		Employee employees[]=new Employee[5];
		
	Scanner scan=new Scanner(System.in);
						 
		for (int i=0;i<=4;i++)
		{
		   employees[i]=new Employee();	
			employees[i].setEmpId(scan.next());
			employees[i].setEmpName(scan.next());
			employees[i].setSalary(scan.nextInt());
		
			
		}
		
//employees[2].getSalary();

      for(Employee emp : employees)
      {
    	  System.out.println(emp);
      }


		 
	}

}
























