package javadayone;

class Customer
{
	//attributes of class
	String custName;
	int age;
	long baseAmount;
	public String getCustName() {
		return custName;
	}
	public void setCustName(String cname) {
		custName = cname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getBaseAmount() {
		return baseAmount;
	}
	public void setBaseAmount(long baseAmount) {
		this.baseAmount = baseAmount;
	}

	private long intAmount; 
	void viewCustomerdata()
	{
		System.out.println("Customer name" + custName + " base amount" + baseAmount + " age is " + age );
			
	}
	void showBalance()
	{
		System.out.println(baseAmount+intAmount);
	}
	long depositAmount(int amount)
	{
		baseAmount+=amount;
		return baseAmount;
		
	}
	long withDraw(int amount)
	{
		return (baseAmount-=amount);
	}
	
	void getInterest()
	{
		
		if (age<=0)
		{
			System.out.println("Invalid age");
		}
		else
		{
		
				if(age>=60)
					intAmount=baseAmount*12/100;
				else if(age>=45)   // 45 to 59
					intAmount=baseAmount*10/100;
				else // less than 45
					intAmount=baseAmount*5/100;
		 System.out.println("Base amount" + baseAmount + " Interest Calculated " + intAmount); 
		}
	}
	
}

public class SampleBank {

	 
	
	public static void main(String[] args) {
		
   Customer custobj=new Customer();  // create object
//   custobj=new Customer();  // allocate memory for object
   
   
custobj.setCustName("Manju");
custobj.setAge(71);
custobj.setBaseAmount(5000);
    
custobj.viewCustomerdata();
  

  
  int answer=(int)custobj.withDraw(500);
  
  System.out.println("Amount after withdraw"  + answer);
  custobj.getInterest();  

  custobj.showBalance();
	}

}
