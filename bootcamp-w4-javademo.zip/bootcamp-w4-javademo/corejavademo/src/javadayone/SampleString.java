package javadayone;

public class SampleString {

	public static void main(String[] args) {
	
		//String is immutable
		
		String name="Mary";
		
	//	name="MaryT";
//		
			
		String custName="Mary";
		
		System.out.println(name.hashCode());
		System.out.println(custName.hashCode());
		
		name="Vani";
		System.out.println("after changing name");
	System.out.println(name.hashCode());

	}

}
