package javadayone;


class Developer
{
	String personName;
	int expr;
	Developer()
	{
		personName="yourname";
		expr=0;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public int getExpr() {
		return expr;
	}
	public void setExpr(int expr) {
		this.expr = expr;
	}
	void displayData()
	{
		System.out.println(" Experience " + expr);
	}
}
class Uidesigner extends Developer
{
	String frameWork;
	
	 void designerData()
	 {
		 personName="David";
		 expr=10;
		 frameWork="Angular";
	 }
	 
	 void displayAlldata()
	 {
		 displayData();
		  System.out.println( " name " + personName + " Frame work" + frameWork);
	 }
}
class Backenduser extends Developer
{
	String database;
}
class TeamLeader extends Developer
{
}
public class SoftwareInherit {
public static void main(String ar[])
{
   Uidesigner uiobj=new Uidesigner();
   uiobj.designerData();
   uiobj.displayAlldata();
}
}
