package javadayone;

import java.util.Scanner;

public class StringArrfruit {

	public static void main(String[] args) {
 
		String[] fruits=new String[5];
		
	//	fruits[0]=new String();
		
		fruits[0]="Apple";
		fruits[1]="Orange";
		fruits[2]="Mango";
		fruits[3]="Jack";
		fruits[4]="Banana";
		
		Scanner scanobj=new Scanner(System.in);
		
		System.out.println("Enter fruit to search");
		String search=scanobj.next();
		
		char avail='n';
//		
//		for(int i=0;i<4;i++)
//		{
//			if (fruits[i].equals(search))
//				avail='y';
//		}

		
		for (String frt : fruits)
		{
			
			if (frt.equals(search))
			avail='y';
		}
		
		
		
		if(avail=='y')
			
		System.out.println("Fruit is avaialble " + search);
		else
			System.out.println("Fruit is not available" + search);
		
		
	}

}
