package javadayone;




public class StringSplit {

	public static void main(String[] args) {

//		String mydata="jan,feb,mar,apr,may";
//		String months[]= mydata.split(",");
//		
//		for (String mon : months)
//			System.out.println(mon);
		
		String statement="Each one take one and we shall,complete  the process";
		
		String[] words=statement.split("where");
		
		System.out.println(words);
		
		
	//	System.out.println(words[6].split(",")[1]);
		
		
		
	}

}
