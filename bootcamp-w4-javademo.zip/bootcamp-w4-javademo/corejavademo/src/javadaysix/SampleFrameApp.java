package javadaysix;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

class MyForm implements ActionListener
{
	
	public JFrame frame;
	JButton button1,button2,button3;
	JTextField txtname;
	void launchFrame()
	{
		frame=new JFrame();
		frame.setLayout(new FlowLayout());
		frame.setSize(200, 300);
		frame.setVisible(true);
		
		button1=new JButton("RED");
		
		button1.addActionListener(this);
		
		button2=new JButton("BLUE");
		
		button2.addActionListener(this);
 
		txtname=new JTextField(10);
		frame.add(button1);
		frame.add(button2);
		frame.add(txtname);
		
		
	}
 
	public void actionPerformed(ActionEvent obj) {
	 
		if(obj.getActionCommand().equals("RED"))
		txtname.setBackground(Color.RED);
		else if(obj.getActionCommand().equals("BLUE"))
			txtname.setBackground(Color.BLUE);
	}
}

public class SampleFrameApp  {

	public static void main(String[] args) {
	
		SwingUtilities.invokeLater(new Runnable()
		{

			 
			public void run() {
			 
				new MyForm().launchFrame();
				
			}
			
		});
	}

}
