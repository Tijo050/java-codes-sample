package javadaysix;

//import javadaysix.Business.Domestic;

class Business
{
	
	String companyname;
	 static Domestic domestic=new Domestic();
	 static International internl=new International();
	
	public static Domestic getDomestic()
	{
		//return new Domestic();
		return domestic;
		
	}
	Business(String cname)
	{
		this.companyname=cname;
	}
	
	void displayAll()
	{
		System.out.println("Company name " + companyname);
	}
	static   public class Domestic
	   {
		   	String locations;
		   	int turnaround;
		   	   void displayLocalagent()
		   	   {
		   		   System.out.println("Delhi,Pune,Mumbai,Calicut");
		   	   }
		   	   int payTax()
		   	   {
		   		  return turnaround*18/100;  
		   	   }
		   
	   }
	 static  public class International
	   {
		    int profit;
		    void countryList()
		    {
		    	System.out.println("UK,US,Japan,China");
		    }
		   
	   }
	
	
	
}


public class SampleInnerclass {

	public static void main(String[] args) {
		
	//System.out.
	//System
		
		Business businessobj=new Business("ABC service");
		
//			businessobj.displayAll();
//			businessobj.domestic.displayLocalagent();
//			businessobj.internl.countryList();
		
	//	Business.domestic.displayLocalagent();
		
	//	Business.getDomestic().displayLocalagent();
		
		Business.Domestic domobj=Business.getDomestic();
		
		//domobj.displayLocalagent();
	

		
	} 

}
