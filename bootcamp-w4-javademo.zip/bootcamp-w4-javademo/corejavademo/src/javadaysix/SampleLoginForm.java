package javadaysix;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

class LoginForm extends JFrame 
{
	JTextField txtname=new JTextField("enter username");
	JPasswordField password=new JPasswordField(8);
	JButton button =new JButton("Login");
	JLabel labeldisplay=new JLabel("");
	LoginForm()
	{
		super("Login Form");
		setLayout(new FlowLayout());
		setSize(200,200);
		
		add(txtname);
		add(password);
		add(button);
	add(labeldisplay);
//		button.addActionListener(
//				
//				new ActionListener()
//				{
//			public void actionPerformed(ActionEvent e) {
//				 
//				String uname=txtname.getText();
//				if(uname.equals("Rao"))
//					labeldisplay.setText("Welcome  " + uname);
//					
//			}
//					
//			}
//				
//			);
		
	
	button.addMouseListener(
			
			new MouseListener()
			{

				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
			}
			
			
			
			
			
			
			
			
			
			);
	
	
	
		
		txtname.addKeyListener(new MyMouseAdapter());

		setVisible(true);
		System.out.println("completed");
	}
	
	class MyMouseAdapter extends KeyAdapter
	{
		public void keyReleased(KeyEvent e) {
			
			String content=txtname.getText();
			 if(!content.equals(""))
				 button.setEnabled(true);
			 else
				 button.setEnabled(false);
		}
	}
	
	

	
	
}
public class SampleLoginForm {

	public static void main(String[] args) {
		 
		SwingUtilities.invokeLater(new Runnable()
				{
			public void run()
			{
				new LoginForm();
			}
				});
		
	}

}
