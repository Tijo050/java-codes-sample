package javadaysix.solid;

interface Switch
{
	boolean swithcon();
	void press();
}

interface UseSwitch
{
	void switchOn();
	void switchOff();
}


class  Light implements UseSwitch
{

	@Override
	public void switchOn() {
System.out.println("Lights on");
		
	}

	@Override
	public void switchOff() {
		System.out.println("Lights off. Its Dark");
		
	}
	
}

class TV implements UseSwitch
{

	@Override
	public void switchOn() {
	System.out.println("Movie is getting played");
		
	}

	@Override
	public void switchOff() {
	System.out.println("Tv switched off");
		
	}
	
}

class ElectricDevice implements Switch
{

	 UseSwitch useswithobj;
	ElectricDevice(UseSwitch uobj)
	{
		this.useswithobj=uobj;
	}
	void pressSwitch()
	{
	    useswithobj.switchOn();
	}
	@Override
	public boolean swithcon() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void press() {
		
	pressSwitch();
	}

}

public class DepencyInverSample {

	public static void main(String[] args) {

		UseSwitch uswithobj=new Light();
		
		Switch switchobj=new ElectricDevice(uswithobj);
		
		switchobj.press();

	}

}
