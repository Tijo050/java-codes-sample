package javadaysix.solid;

interface iRailway
{
	void showAvaialbility();
	
}

interface iManager extends iRailway
{
	void addTrains();
	void showPassengerlist();
	
}
interface iPassenger extends iRailway
{
	void printTicket();

	void authenticateUser();
	
}

class Passenger implements iPassenger
{

	@Override
	public void showAvaialbility() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTicket() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void authenticateUser() {
		// TODO Auto-generated method stub
		
	}

	
	
}

class RailwayAdmin  implements iManager,iPassenger
{

	@Override
	public void showAvaialbility() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addTrains() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showPassengerlist() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTicket() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void authenticateUser() {
		// TODO Auto-generated method stub
		
	}

	 
	
}


public class InterfaceSegreSample {

	public static void main(String[] args) {
		 
		iRailway railwayobj=new Passenger();
		
		 
		iManager railwayobj2=new RailwayAdmin();
		railwayobj2.showAvaialbility();
	}

}
