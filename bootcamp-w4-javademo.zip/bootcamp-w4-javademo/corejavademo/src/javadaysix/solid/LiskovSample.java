package javadaysix.solid;

abstract class Employee
{
	abstract void processPayrole();
	 
}

class InhouseEmployee extends Employee
{
	void processPayrole()
	{
		System.out.println("payrole system");
	}
	void processAppraisal(int expr) throws Exception
	{
		System.out.println("appraisal processed");
	}

}

class PermEmployee extends InhouseEmployee
{
	
	
}
class Manager extends InhouseEmployee
{
	void processAppraisal(int expr) throws Exception
	{
		System.out.println("20% appraisal processed ");
	}
}

class TemporaryEmployee extends Employee
{

	void processPayrole()
	{
	System.out.println("hourly paid");	
	}
	
	
}
public class LiskovSample {

	public static void main(String[] args) throws Exception {
	 
		Employee emp1=new Manager();
		Employee emp2=new TemporaryEmployee();
		
		emp1.processPayrole();
		
		emp2.processPayrole();
		
			}

}
