package javadaysix.solid;

interface iVaccinate
{
	void vaccinateProcess();
}
class Children implements iVaccinate
{
public	void vaccinateProcess()
{
	System.out.println("Date yet to be declared. please wait");
}
}

class MiddleAge implements iVaccinate
{
	public	void vaccinateProcess()
	{
		System.out.println("Currently Applicable. Vaccinate yourself");
	}
}
class Young implements iVaccinate
{
	public	void vaccinateProcess()
	{
		System.out.println("Starts from May 1st. But keep wait till next announcement");
	}
}
class StateAction //open for extension closed for modification
{
	 public void vaccinatePerson(String date,iVaccinate vacobj )
	 {
		  System.out.println("Vaccianted date is" + date);
		  vacobj.vaccinateProcess();
	 }
	
}

public class SampleOpenClosed {

	public static void main(String[] args) {
 
		Young youngobj=new Young();
		MiddleAge mage=new MiddleAge();
		Children childobj=new Children();
		
		StateAction stateobj=new StateAction();
		stateobj.vaccinatePerson("5thMay", childobj);
		
		
		
		
		
	}

}
