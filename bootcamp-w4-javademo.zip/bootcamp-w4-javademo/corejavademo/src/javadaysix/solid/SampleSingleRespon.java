package javadaysix.solid;

class Customer
{
	  String cname;
	  int age;
	  Customer(String cn,int age)
	  {
		  this.cname=cn;
		  this.age=age;
		  
	  }
	    public Scheme addScheme()
	    {
	    	return new Scheme();
	    }
public LogReport addLogs()
{
	return new LogReport();
}

	  }
 
class Scheme
{
	
	
	  void showScheme(String s)
	  { 
		System.out.println("Winter Scheme" + s);  
		  
	  }
}
class LogReport
{
	  void sheemeLogs()
	  {
		System.out.println("printing the details of customer with scheme......");  
	  }
}


public class SampleSingleRespon {

	public static void main(String[] args) {
		
		Customer customer=new Customer("Kavitha",23);
		customer.addScheme().showScheme("Savelife");
		
		
	}

}
