package javadaythree;

import java.util.Scanner;

public class ExceptionSample {

	public static void main(String[] args) {
	 
		 int arr[]=new int[2];
		Scanner scan=new Scanner(System.in);
		try
		{
		System.out.println("Enter number");
		String number1=scan.next();
		
		int num=Integer.parseInt(number1);
		int ans=25/num;
		//arr[3]=ans;
		System.out.println("Square is " + num*num);
		System.out.println("ans " + ans);
		 
		}
	catch(NumberFormatException numexcept)
		{
			System.out.println(numexcept);
		}
		catch(ArithmeticException arithexc)
		{
			System.out.println("The divisor can not be zero");
		}
		catch(Exception excep)
		{
			System.out.println(excep);
		}
		finally
		{
			System.out.println("number process done");
			
		}
		
		
		
		
		
		System.out.println("Welcome to calcuator");
		
	}

}
