package javadaythree;

public class InvalidAgeException extends Exception
{
  InvalidAgeException(String msg)
  {
	  super(msg);
  }
}
