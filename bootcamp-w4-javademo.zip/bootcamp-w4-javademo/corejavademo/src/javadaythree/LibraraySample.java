package javadaythree;

 class Book
{
	String bookname;
	String author;
	static String publisher;
	static int count;
	
	
	
	
static	
	{
	publisher = "MVC Publishers";
	count=0;
	  System.out.println("ABC Library");	
	}
	
	Book(String bname,String author)
	{
		this.bookname=bname;
		this.author=author;
		count++;
	}
	
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
 void display()
 {
	 System.out.println("bookname" + bookname + "author "  + author  + " publis" + publisher );
	// visitorCount(); possible
 }
  static void visitorCount()
  {
	  System.out.println( " user count " + count );
	//  display(); not possible
  }
 
}




public class LibraraySample {

	public static void main(String[] args) {
	 
		 Book.publisher="MS publishers";
			
		 Book bookobj1=new Book("Python","Arun maxwell");
		 
		 bookobj1.display();
		 bookobj1.visitorCount();
		 
		 Book bookobj2=new Book("Java","Xantra");
		  bookobj2.display();
		
		 
		  Book bookobj3=new Book("ASP","Anoop");
		  bookobj3.display();
		 
		  Book.visitorCount();

		
		


		 
	}

}
