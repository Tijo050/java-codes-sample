package javadaythree;

import java.util.ArrayList;
import java.util.List;


class BookCustomer
{
	String customerName;
	List<StoryBook> storybooks;
	

	BookCustomer(String cname,List<StoryBook> bks)
	{
		customerName=cname;
		storybooks=bks;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public List<StoryBook> getStorybooks() {
		return storybooks;
	}
	public void setStorybooks(List<StoryBook> storybooks) {
		this.storybooks = storybooks;
	}
	
	void displayData()
	{
		System.out.println(customerName);
		 for(StoryBook bookobj : storybooks)
		 {
			 System.out.println(bookobj);
		 }
	}
}
public class LibraryComposition {
	public static void main(String[] args) {
	 	List<StoryBook> books=new ArrayList<StoryBook>();
		StoryBook book1=new StoryBook(10,"Fairy tale");
		StoryBook book2=new StoryBook(20,"History incidents");
		books.add(book1);
		books.add(book2);
		BookCustomer bookcustomer=new BookCustomer("Nithya",books);
		bookcustomer.displayData();
	}

}
