package javadaythree;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

interface iBookaccess
{
	void addBook(StoryBook storybook);
	StoryBook findBook(int bookid);
	boolean deleteBook(int bookid);
	void viewAll();
}

class CustomerAccess implements iBookaccess
{
	  String custname;
	  List<StoryBook> books;
	  
	 CustomerAccess(String cname)
	 {
		 this.custname=cname;
		 books=new ArrayList();
	 }

 
	public void addBook(StoryBook storybook) {
		books.add(storybook);
	 	
	}

 
	public StoryBook findBook(int searchid) {
		StoryBook resultobj=null;
		
		for(StoryBook book : books)
		{
			 if(book.getBookid()==searchid)
				 resultobj=book;
				 
		}
		return resultobj;
	 }

 
	public boolean deleteBook(int bookid) {
		StoryBook findbk=findBook(bookid);
		if(findbk==null)
			return false;
		
		ListIterator iterateobj=books.listIterator();
		while(iterateobj.hasNext())
		{
			StoryBook book=(StoryBook)iterateobj.next();
			
			if(book.bookid==bookid)
			iterateobj.remove();
			
		}
		return true;
		
	 }

	 
	public void viewAll()
	{
	   for(StoryBook book : books)
		   System.out.println(book);
	}
	
	
}


class CustomerService 
{
    //factory methods	 
	  public static CustomerAccess getCustomerAccess(String n)
	  {
		  return new CustomerAccess(n);
	  }
	
	
}



public class LibraryInterfacePattern {

	public static void main(String[] args) {
 
		//iBookaccess bookaccess=new CustomerAccess("Mary");
		
		iBookaccess bookaccess=CustomerService.getCustomerAccess("Mary");
		
		
		
		StoryBook book1=new StoryBook(1,"Angel");
		
		StoryBook book2=new StoryBook(2,"Thriller");
		
		StoryBook book3=new StoryBook(3,"Comedy");
		
		bookaccess.addBook(book1);
		bookaccess.addBook(book2);
		bookaccess.addBook(book3);
		
		bookaccess.viewAll();
		
		System.out.println("Before Deleting 1st book");
		
		bookaccess.deleteBook(1);
		
		bookaccess.viewAll();
		
		

	}

}
