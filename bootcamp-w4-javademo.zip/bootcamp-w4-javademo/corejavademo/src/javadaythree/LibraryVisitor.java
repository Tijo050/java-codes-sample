package javadaythree;

final class LibraryCard
{
	String cardnumber;
	final String bookid;
	LibraryCard()
	{
		bookid="b100";
	}
	public String getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}
	public String getBookid() {
	//	bookid="b100";
		return bookid;
	}
 
	
}
class Reader  
{
	String readerName;
	void displayData()
	{
		LibraryCard card=new LibraryCard();
 		card.setCardnumber("c100");
 	//	card.bookid="B101";
		readerName="Mary";
		System.out.println(readerName + card.getCardnumber());
	}
	
}

public class LibraryVisitor {

	public static void main(String[] args) {
 
Reader reader=new Reader();
reader.displayData();
	}

}
