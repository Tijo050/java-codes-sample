package javadaythree;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

class Item
{
	String itemid;
	String itemname;
	int price;
  public String toString()
  {
	  return "Item id "+ itemid ;
  }

}


public class ListSample {

	public static void main(String[] args) {
	
		List<Item> listcolor=new ArrayList<Item>();
		Item itemobj=new Item();
		
		
//		listcolor.add("Red");
//		listcolor.add("White");
//		listcolor.add("Blue");
//		listcolor.add(24);
	listcolor.add(itemobj);
	listcolor.add(new Item());	
		System.out.println(listcolor);
		
		
		ListIterator iterobj=listcolor.listIterator();
		
       while(iterobj.hasNext())
       {
  //  	    String item=iterobj.next();
    	   
    	   Item obj=(Item) iterobj.next();
//    	    
//    	    if(iterobj.equals("White"))
//    	    	System.out.println("White color exist");
//    	    	
    	    
    	    System.out.println(iterobj.next());
    	     
       }
		
		
	}

}
