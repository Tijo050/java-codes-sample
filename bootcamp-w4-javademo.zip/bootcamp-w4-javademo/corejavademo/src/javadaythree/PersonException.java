package javadaythree;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

class Person
{
	String pname;
	int age;
	Person(String pname,int age)
	{
	  this.pname=pname;
	  this.age=age;
			
	}
 
}
public class PersonException {

	public static void main(String[] args) throws InvalidAgeException
	{
		
	//	char ch=(char)System.in.read();
		
		
		Scanner scan=new Scanner(System.in);
	 int age=scan.nextInt();
	 
	 if(age<0)
		 throw new InvalidAgeException("Age can not be -ve"); // checked exception
	
	 Person person=new Person("Arun",age);
	//System.out.println("Weclome " + person.pname + " you are " + person.age + "yrs old");
	}

}
