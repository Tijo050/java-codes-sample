package javadaythree;

public class StoryBook
{
	  int bookid;
	  String bookName;
	  StoryBook(int bookid,String bookname)
	  {
		  this.bookid=bookid;
		  this.bookName=bookname;
	  }
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
 
	  public String toString()
	  {
		  return "Book name " + bookName;
	  }
}
