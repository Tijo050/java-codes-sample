package javadaytwo;
class Calculator
{
	void add(int n1,int n2)
	{
		System.out.println(n1+n2);
	}

//	int add(int n1,int n2)
//	{
//		return(n1+n2);
//	}

	
	void add(int n1,float n2)
	{
		System.out.println(n1+n2);
	}
	void add(float n1,float n2,float n3)
	{
		System.out.println(n1+n2+n3);
	}
	void add(String a,String b)
	{
		System.out.println(a+b);
	}
	
}
public class CalculatorProcess {

	public static void main(String[] args) {
	
		Calculator sonycalci=new Calculator();
		sonycalci.add("Mary", " Theresa");

	}

}
