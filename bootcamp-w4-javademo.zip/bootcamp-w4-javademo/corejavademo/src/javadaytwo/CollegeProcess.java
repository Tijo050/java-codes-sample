package javadaytwo;

class Course
{
	String courseName;
	int duration;
	Course()
	{
		courseName="Java";
		duration=45;
	}
	
}

class Program extends Course
{
	String programname;
	int fees;
	Program()
	{
		programname="Stackroute java fullstack";
		fees=10000;
	}
	
}


class Headoffice extends Program
{
	String orgName;
	String location;
	Headoffice()
	{
		orgName="Stackroute";
		location="Bangalore";
	}
}

class Institute extends Headoffice
{
	String branchName;
	String manager;
	Institute()
	{
		branchName="Chennai";
		manager="Ravi";
		duration=100;
	}
	void showDetails()
	{
		System.out.println("branch Name" + branchName +  "program " + programname + "duration " + duration);
	}
	
}


public class CollegeProcess {

	public static void main(String[] args) {

Institute myinstitute=new Institute();
myinstitute.showDetails();


	}

}
