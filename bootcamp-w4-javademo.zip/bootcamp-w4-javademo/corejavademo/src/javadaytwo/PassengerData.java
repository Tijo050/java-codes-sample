package javadaytwo;

//interface - behaviour protocols

interface TicketProcess
{
	void bookTicket(int num);
	void cancelTicket(int num);
}

interface Commonprocess
{
	 public void getAlldata();
	//abstract void printTicket();
	 void showDetails();
	
}

interface newProcess
{
	abstract void checkTemp();
}

class Book implements Commonprocess
{
 
	public void getAlldata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showDetails() {
		System.out.println("author name : anju bookname : c++ ");
		
	}
	
}

interface ticketAdmin
{
	void showTicketCount();
}

class Ticket implements Commonprocess,ticketAdmin
{

	public void showTicketCount()
	 {
		 
	 }
	 void addTickercount()
	 {
		 
	 }

	@Override
	public void showDetails() {
System.out.println("ticketavaila is 150" );		
	}

	@Override
	public void getAlldata() {
		// TODO Auto-generated method stub
		
	}
	
}

interface Internorms
{
void	railwayNorms();
}

class Passenger implements Commonprocess, newProcess,Internorms

{

public void railwayNorms()
{
	System.out.println("new norms");
}
	
	@Override
	public void checkTemp() {
		// TODO Auto-generated method stub
		
	}

	

	@Override
	public void showDetails() {
	System.out.println("ticket number : date :  ");
		
	}

	@Override
	public void getAlldata() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}

class RailwayAdmin 
{

	
 ticketAdmin admin=new Ticket();

	
	public void bookTicket(int num) {
		admin.showTicketCount();
		// TODO Auto-generated method stub
		
	}
	public void cancelTicket(int num) {
		// TODO Auto-generated method stub
		
	}

	

	public void showDetails() {
	System.out.println("total trains 120, north 20, east -20");
	}

	public void getAlldata() {
		// TODO Auto-generated method stub
		
	}
	
	
}


public class PassengerData {

	public static void main(String[] args) {
 
//		RailwayAdmin adminobj=new RailwayAdmin();
	//	adminobj.showDetails();
 
    Passenger passobj=new Passenger(); //PassengerData and Passenger classes are tightly coupled
    
    
    
   // passobj.showDetails();
    
    
    Commonprocess commonobj;
    
    //	commonobj=new RailwayAdmin();
    	 //or
    	commonobj=new Passenger();   //PassengerData and Paggesnger classes are loosly coupled
    	
     	commonobj.showDetails();
    	commonobj.getAlldata();
    	
    	Internorms internorms=new Passenger();
    	
    	
    	
	}

}
