package javadaytwo;

abstract class Person
{
	String name;
	int age;
	Person()
	{
		name="paul";
		age=25;
	}
	abstract void showDetails();
	 
}

class Manager extends Person
{
	String dept;
	int salary;
	Manager()
	{
		dept="testing";
		salary=20000;
	}
	void meetingAgenda()
	{
		System.out.println("m,w,f- 9 to 11am");
	}
	void showDetails()
	{
		System.out.println(" Details are of manager  : name is " +  name + "Dept is " + dept +  " sala is " + salary);
	}
	
}

class Developer extends Person
{
	String technology;
	int expr;
	Developer()
	{
		technology="java";
		expr=20;
	}
	void deployProject()
	{
		System.out.println("ON Stage 2 server");
	}
	void showDetails()
	{
		System.out.println(" developer Details are name is " + name  + " technology  " +  " expr is " + expr);
	}
}


public class ProcessEmployee {

	public static void main(String[] args) {
	 
//		
//		Manager manager1=new Manager();
//		manager1.showDetails();
//		Developer developer1=new Developer();
//		developer1.showDetails();
//			
		
		Person person1;
		
			person1=new Manager();
		
	   printData(person1);
					
	}
	
static void printData(Person person)
	{
	

	   if( person instanceof Developer)
	   {
		   Developer devobj=(Developer)person;
		   devobj.deployProject();
		System.out.println("devel instance");
		
	   }
	   else if(person instanceof Manager)
	   {
		   Manager manager=(Manager)person; // downward casting
		   manager.meetingAgenda();
		  System.out.println("manager instance"); 
	   }
	   
	   person.showDetails();
		
	}

}
