package javadaytwo;

class University
{
	 String universityName;
	 String location;
	 University()
	 {
		 System.out.println("inside baseclass - university");
		 universityName="Indira Gandhi University";
		 location="Delhi";
	 }
	 University(String uniname,String location)
	 {
		 System.out.println("Inside baseclass constur with argument");
		 this.universityName=uniname;
		 this.location=location;
	 }
	public String getUniversityName() {
		return universityName;
	}
	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
 	public void displayDetails()
	{
		System.out.println("Universtiy name" + universityName + " Location " + location);
	}
	}

class Artscollege extends University
{
	 String collegename;
	 String course;
	 Artscollege()
	 {
		 System.out.println("inside child class- artscolle");
		  collegename="Holycross";
		  course="MCA";
				  
	 }
	 
	 Artscollege(String cname,String course)
	 {
		 super("Mother Tresa","WBengal"); // call base class constructor with 2 string arguments
		 this.collegename=cname;
		 this.course=course;
	 }
	 
	 
	public void displayDetails()
	 {
		super.displayDetails();
		  System.out.println(" College " + collegename + " course " + course);
	 }
	
}

class Engcollege extends University
{
	String collegename;
	String technology;
	 Engcollege()
	 {
		 System.out.println("insde child class- engcolle");
		 collegename="SRM Engineering";
		 technology="M.Tech";
	 }
	public void displayDetails()
	 {
		 System.out.println("Universtiy " + universityName + " College " + collegename + " technol " + technology);
	 }
}
public class UniversityProcess {
	public static void main(String ar[])
	{
		Artscollege artobj1=new Artscollege("MBK college","M.Phil");
		artobj1.displayDetails();
		Engcollege engobj1=new Engcollege();
		engobj1.displayDetails();
	}

}
