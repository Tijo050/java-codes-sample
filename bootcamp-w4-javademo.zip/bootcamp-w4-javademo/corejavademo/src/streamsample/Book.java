package streamsample;

import java.io.Serializable;

public class Book implements Serializable {
int bookid;
String bname;
int price;
public Book() {}
public Book(int id,String bname,int price)
{
	this.bookid=id;
	this.bname=bname;
	this.price=price;
}
public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
public String getBname() {
	return bname;
}
public void setBname(String bname) {
	this.bname = bname;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String toString()
{
	return "id is " + bookid + " name " + bname + "price" + price;
}
}
