package streamsample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringBufferInputStream;

public class ConsoleSample {

	public static void main(String[] args) throws IOException {
		 
		System.out.println("enter your name");
		
//		InputStream inputobj1=new StringBufferInputStream("hello");
//		inputobj1.r
//		
		
		InputStreamReader inputobj=new InputStreamReader(System.in);
		BufferedReader breader=new BufferedReader(inputobj);
		
		String data=breader.readLine();
		
		System.out.println("welcome " + data);
		
		
		
	}

}
