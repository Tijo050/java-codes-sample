package streamsample;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class CsvProcess {
	public static void main(String[] args) throws Exception {

		User user;
		List<User> userlist=new ArrayList<User>();
		
		 Properties myprop=SampleProperty.getProperty();
		 String filename=myprop.getProperty("filename");
		 
		 
		FileReader fileread=new FileReader("user.csv");
		BufferedReader bread=new BufferedReader(fileread);

		//Reading first line, which is header
		String fline=bread.readLine();


		String fcontent;
		
		//Reading from the second line, which are content
		while( (fcontent=bread.readLine())!=null)
		{
			
			String data[]=fcontent.split(",");
			
			user=new User(data[0],Integer.parseInt(data[1]),data[2]);
			userlist.add(user);
			
//			if(data[2].equals("mumbai"))
//			System.out.println(fcontent);
		}  // while
		
		for(User userobj : userlist)
			System.out.println(userobj);
		

	}

}
