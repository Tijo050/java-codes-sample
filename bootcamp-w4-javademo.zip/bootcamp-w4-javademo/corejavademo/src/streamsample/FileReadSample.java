package streamsample;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReadSample {

	public static void main(String[] args) throws Exception {
FileReader fileread=new FileReader("sample.txt");
BufferedReader bread=new BufferedReader(fileread);

String line;
while( (line=bread.readLine())!=null)
{
	System.out.println(line);
}
	}

}
