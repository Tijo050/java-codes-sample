package streamsample;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class FileWriteSample {

	public static void main(String[] args) throws IOException {
	
//		OutputStreamWriter outobj=new FileWriter("ustg.txt");
//		outobj.write("hello");
//		outobj.flush();
//		
		
//		OR
		
		FileWriter filename=new FileWriter("sample.txt",true);
		BufferedWriter bwrite=new BufferedWriter(filename);
	
		bwrite.write("\nAm checking flush method");
		
		bwrite.flush();
 System.out.println("File created");
 
	}

}
