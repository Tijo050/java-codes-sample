package streamsample;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

public class NioSample {

	public static void main(String[] args) throws Exception {
		Path pathsource=Paths.get("E:\\01-bootcamp2-ustg\\wednesnio"); 
 
	if(	Files.isDirectory(pathsource))
		System.out.println("directory exists");
	else
		System.out.println("Invalid");
	
	 pathsource=Paths.get("E:\\01-bootcamp2-ustg\\wednesnio\\helloworld.txt"); 
	Path pathdesti=Paths.get("E:\\01-bootcamp2-ustg\\quiz\\abc.txt");
	
	Files.copy(pathsource, pathdesti,StandardCopyOption.REPLACE_EXISTING);
	
	System.out.println("Copied");

//	 pathsource=Paths.get("E:\\01-bootcamp2-ustg\\wednesnio\\testing"); 
//	Files.createDirectory(pathsource);
	
	System.out.println("Folder created");

Path pathdata=Paths.get("E:\\01-bootcamp2-ustg\\Exercise\\week3\\streamplayer.txt"); 

if(Files.isReadable(pathdata))
{
	List<String> lines=Files.readAllLines(pathdata);
	
	for(String line : lines)
	{
		System.out.println(line);
	}
	
}
	
	
	}

}
