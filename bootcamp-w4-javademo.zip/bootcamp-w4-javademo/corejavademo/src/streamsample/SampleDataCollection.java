package streamsample;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class SampleDataCollection {

	public static void main(String[] args) throws Exception {
Book book1=new Book(10,"C++",200);
Book book2=new Book(20,"Java",300);
List<Book>  books=new ArrayList<Book>();
	
	books.add(book1);
	books.add(book2);
	FileOutputStream fileout=new FileOutputStream("booklist.dat",true);

	ObjectOutputStream objoutput=new ObjectOutputStream(fileout);
	
	objoutput.writeObject(books);
	System.out.println("fiel created");
	
	}
	

}
