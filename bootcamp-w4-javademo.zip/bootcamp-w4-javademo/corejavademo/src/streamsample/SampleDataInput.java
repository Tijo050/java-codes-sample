package streamsample;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class SampleDataInput {

	public static void main(String[] args) throws Exception {
FileOutputStream fileout=new FileOutputStream("fruit.txt");
DataOutputStream dataoutput=new DataOutputStream(fileout);

dataoutput.writeInt(100);
dataoutput.writeChars("Apple");
System.out.println("fruit data created");

FileInputStream fileinp=new FileInputStream("fruit.txt");
DataInputStream datainp=new DataInputStream(fileinp);

int price=datainp.readInt();

System.out.println("price is " + price);



	}

}
