package streamsample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.util.List;

public class SampleDatacollRead {

	public static void main(String[] args) throws Exception {
		FileInputStream fileinput=new FileInputStream("booklist.dat");
		ObjectInputStream objinput=new ObjectInputStream(fileinput);
		
		
		List<Book> books=(List<Book>)objinput.readObject();
		
		for(Book bk : books)
		{
			System.out.println(bk);
		}
		

	}

}
