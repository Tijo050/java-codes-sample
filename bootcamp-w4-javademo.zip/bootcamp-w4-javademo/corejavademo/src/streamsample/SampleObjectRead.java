package streamsample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;

public class SampleObjectRead {

	public static void main(String[] args) throws Exception {
FileInputStream fileinput=new FileInputStream("bookdatanew.dat");
ObjectInputStream objinput=new ObjectInputStream(fileinput);

Book book;
while( (book=(Book)objinput.readObject())!=null)
	System.out.println(book);

	}

}
