package streamsample;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SampleObjectStore {

	public static void main(String[] args) throws Exception {
Book bookobj=new Book(200,"Python",200);
FileOutputStream fileout=new FileOutputStream("bookdatanew.dat",true);

ObjectOutputStream objoutput=new ObjectOutputStream(fileout);
objoutput.writeObject(bookobj);
System.out.println("Book object stored");

	}

}
