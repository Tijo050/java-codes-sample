package streamsample;

import java.util.Properties;

public class SampleProperty {

 static	public Properties getProperty() {
 
		Properties prop=new Properties();
		prop.put("filename", "fruit.txt");
		prop.put("username","Mary");
		
		prop=System.getProperties();
		prop.list(System.out);
		
		//System.out.println(prop.get("filename"));
		return prop;
		
	}

}
