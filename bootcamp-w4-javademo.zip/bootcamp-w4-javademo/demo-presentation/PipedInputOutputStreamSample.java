package com.ust.in;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
public class PipedInputOutputStreamSample {
	
	final static  PipedOutputStream Pout = new PipedOutputStream();
	
	final static PipedInputStream Pin = new PipedInputStream();
	
	public static void main(String[] args) throws IOException {
		
		 Pout.connect(Pin);
		
		 write wrt = new write();		
		 read rd = new read();
		
		    wrt.start();
		    rd.start();
		
		
		   // thread1.start();
		
		    //thread2.start();
		
	}		
		// using functional interface				
	//static Thread thread1 = new Thread() {		
  static class write extends Thread{
		
		public void run() {				
			
					try {
						
						for (int i=10;i<=15;i++)						
						{
							Pout.write(i);
							Pout.write(i+2);
							System.out.println(" I am writing into pipeline Output stream " + i);
							System.out.println(" I am writing into pipeline Output stream " + (i+2));
							
					//		it will stop  POS up to transfer entire data from POS to PIS
							Pout.flush();
													
							Thread.sleep(1500);
						}
																
					   Pout.close();
						
					}//try
					
					catch (Exception e) {
						System.out.println(e.getMessage());
						
					}//try
									
				}
				
	        };
	        			
	       // static  Thread thread2 = new Thread()	{
	        static class read extends Thread{
	        	
	               int Readdata;
	               byte[] b = new  byte[2];
	              
	              public void run() {
	            	 
						try {
										
							//Check how many bytes of data is there	
							
						System.out.println( " bytes of data available "  + Pin.available());
//							
//						    while((Pin.read(b,0,1))!= -1) {
//								
//						System.out.println(" I am Reading into pipeline Input stream " + b[0]);
								
						    while((Readdata=Pin.read())!= -1) {
							System.out.println(" I am Reading into pipeline Input stream " + Readdata);
														
							}
							
							     Pin.close();		   
							
						    }//try
						
						       catch (Exception e)
						     {
							          System.out.println(e.getMessage());
							
						     }//catch
					 }//run
	            };
	       
	        }