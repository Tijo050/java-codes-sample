package com.stackroute.java8day6;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.stackroute.java8day6.model.Student;

public class NIOCsvObject {

	static List<Student> studentlist=new ArrayList<Student>();
	public static void main(String[] args) throws Exception {
	
		Path mypath=Paths.get("E:\\01-bootcamp2-ustg\\javademo\\data\\student.csv");
		BufferedReader bread=Files.newBufferedReader(mypath);
		
		String data;
				while( ( data=bread.readLine())!=null)
				{
				//	System.out.println(data);
					convertToStudent(data);
				}
				
			//studentlist.forEach(System.out::println);	
			
			//sort using doj
			
		//	studentlist.stream().sorted((Comparator.comparing(sobj->sobj.getDoj()).reversed()).collect(Collectors.toList()).forEach(System.out::println);
				
				studentlist.stream().sorted(Comparator.comparing(Student::getDoj).reversed()).collect(Collectors.toList()).forEach(System.out::println);
				
			List<Student> studlist=	studentlist.stream().filter( s-> s.getGroupname().contains("Biology")).collect(Collectors.toList());
				
			}
	
	static void convertToStudent(String fileline)
	{
	DateTimeFormatter dtformat=DateTimeFormatter.ofPattern("yyyy/MM/dd");
		
		String content[]=fileline.split(",");
	Student studobj=new Student(Integer.parseInt(content[0]),content[1],content[2],Integer.parseInt(content[3]),
					Integer.parseInt(content[4]),content[5],content[6],LocalDate.parse(content[7], dtformat));
			
			studentlist.add(studobj);
	
		
	}
	

}
