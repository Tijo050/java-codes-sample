package com.stackroute.java8day6;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NioFileDirectorySample {

	public static void main(String[] args) {

		// to get the pdf files in the given folder , here it is ppts
		
		Path path=Paths.get("E:\\01-bootcamp2-ustg\\PPTs");
		
	try(Stream<Path> streamdata=Files.walk(path))   // try with resource
			{
		
//					streamdata.forEach(  p-> {
//						
//					  if(	Files.isDirectory(p))
//					  {
//						  System.out.println (p + "is a directory");
//					  }
//					  else
//						  System.out.println(p + " is a file");
//					 
//					});
					
					
		
		 List<String> filesnames=streamdata.map( obj-> obj.toString())
						   				.filter( str-> str.endsWith(".pdf") )
						   					.collect(Collectors.toList());
		 
		 filesnames.forEach(System.out::println);

			}
	catch(Exception e)
	{
		
	}
	
	}

}
