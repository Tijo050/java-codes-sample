package com.stackroute.java8day6;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NioStreamSample {

	public static void main(String[] args) throws Exception {
		
		FileReader myfile=new FileReader("bootcamp.txt");
		BufferedReader bread=new BufferedReader(myfile);
		
		Stream<String> filelinestream=bread.lines();
			
//	List<String> filedata=filelinestream.filter( str-> str.contains("exercise")).collect(Collectors.toList());
//	filedata.forEach(System.out::println);
	
	
 long total=filelinestream.filter( str-> str.contains("exercise")).count();
 
 System.out.println("Toal exercises are " + total);
 
 
 
 

		
	}

}
