package com.stackroute.java8day6;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class SampleIntStream {

	public static void main(String[] args) {
	
		
	List<Integer> numbers=IntStream.iterate(5, i->i+2).
			                          mapToObj(Integer::valueOf)
			                          .limit(10)
			                          .collect(Collectors.toList());
	

	numbers.forEach(System.out::println);
	
	}

}
