package com.stackroute.java8day6;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.time.LocalTime;

import static java.nio.file.StandardWatchEventKinds.*;


class MonitorFolder
{
	WatchService wservice;
	
	void registerfolder()
	{
		
	
		try {
			wservice=FileSystems.getDefault().newWatchService();
			
			Path mypath=Paths.get("E:\\01-bootcamp2-ustg\\quiz");
			
			mypath.register(wservice,ENTRY_CREATE,ENTRY_DELETE,ENTRY_MODIFY);
		} 
		
		catch (IOException e) {
			
		}
	}
	
	void notifyChange()
	{
		WatchKey wkey=null;
		
		while(true)
		{
			
		try {
			wkey=wservice.take();
		    
			for( WatchEvent evnt : wkey.pollEvents())
			{
				System.out.println (evnt.context().toString() + " is " + evnt.kind() + LocalTime.now());
			}
		 }
		
		catch (InterruptedException e)
		{
		
		}
			
		boolean rest=wkey.reset();
			if(!rest)
				break;
		}
		
			}
}





public class SampleWatchService {
	
	public static void main(String[] args) {
System.out.println("Monitoring changes in my quiz folder");
		MonitorFolder mfolder=new MonitorFolder();
		mfolder.registerfolder();
		mfolder.notifyChange();
	}

}
