package com.stackroute.java8day6.model;

import java.time.LocalDate;

public class Student {

	int rollno;
	String name;
	String groupname;
	int total;
	int rank;
	String addr;
	String schoolname;
	LocalDate doj;
	
   	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getSchoolname() {
		return schoolname;
	}
	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}
	public Student(int rno,String nm,String gp,int tot,int rk, String addr,String sname,LocalDate doj)
   	{
   		this.rollno=rno;
   		this.name=nm;
   		this.groupname=gp;
   		this.total=tot;
   		this.rank=rk;
   		this.addr=addr;
   		this.schoolname=sname;
   		this.doj=doj;
   				
   	}
	
   	public String toString()
   	{
   		return "name " + name + " rank " + rank + " group name " + groupname + " schoolname" + schoolname + "addr " + addr + " Total " + total + "date of join" + doj;
    	}
   	
	
}
