package com.stackroute.java8dayfive;

public class Customer {

	String customerName;
	int age;
	Policy policy; //composition relationship
	
	public Customer(String cname,int age,Policy policyobj)
	{
		this.customerName=cname;
		this.age=age;
		this.policy=policyobj;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Policy getPolicy() {
		return policy;
	}
	public void setPolicy(Policy policy) {
		this.policy = policy;
	}

	 public String toString()
	 {
		 return "Customer" + customerName + "Policy" + policy.toString();
	 }
}
