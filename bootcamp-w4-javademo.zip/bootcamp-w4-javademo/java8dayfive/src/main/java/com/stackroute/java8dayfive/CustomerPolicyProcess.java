package com.stackroute.java8dayfive;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class CustomerPolicyProcess {

	public static void main(String[] args) {
Policy p1=new Policy("Sampoorna",5000,15);
Policy p2=new Policy("Wedding",6000,10);
Policy p3=new Policy("Retire",5000,20);

Customer customer1=new Customer("Alex",20,p1);
Customer customer2=new Customer("Varun",30,p2);
Customer customer3=new Customer("Wilson",12,p1);
Customer customer4=new Customer("Saran",24,p2);
Customer customer5=new Customer("Padma",45,p3);

List<Customer> customers=Arrays.asList(customer1,customer2,customer3,customer4,customer5);


// Customers enrolled for wedding policy

List<Customer> custresult=    customers.stream().filter( cust-> cust.getPolicy().getPolicyname().equals("Wedding")).limit(10).collect(Collectors.toList());
//custresult.forEach( System.out::println);

//Customers who have enrolled for Max duration policy

   Optional<Customer> custopt=customers.stream().max(Comparator.comparing(cust-> cust.getPolicy().getPeriod()));
//   if(custopt.isPresent())
//	   System.out.println(custopt.get());

   
 // Count the customers who have enrolled for each policy
   Map<String,Long> custcount=customers.stream().collect( Collectors.groupingBy(  cust->cust.getPolicy().getPolicyname() ,Collectors.counting()));
   
   custcount.forEach(  (k,v) -> System.out.println (k + " customer cuount " + v));

	}

}
