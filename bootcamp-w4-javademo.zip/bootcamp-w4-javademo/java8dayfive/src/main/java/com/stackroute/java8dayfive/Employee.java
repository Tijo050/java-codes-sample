package com.stackroute.java8dayfive;

import java.time.LocalDate;

public class Employee {

	String empname;
	LocalDate dob;
	LocalDate doj;
	String addr;
	int salary;
	
	public Employee(String ename,LocalDate dateofbirth,LocalDate datejoin,String addr,int sal)
	{
		this.empname=ename;
		this.dob=dateofbirth;
		this.doj=datejoin;
		this.addr=addr;
		this.salary=sal;
				
	}
	
	
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public String toString()
	{
		return "name " + empname + " Dob " + dob + "doj " + doj +  " salary " + salary;
	}
	
}
