package com.stackroute.java8dayfive;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

//String empname;
//LocalDate dob;
//LocalDate doj;
//String addr;
//int salary;

public class EmployeeDateFun {

static	List<Employee> employees=new ArrayList<Employee>();
	public static void main(String[] args) {
	
		Employee emp1=new Employee("Anju",LocalDate.of(1995, 12, 20),LocalDate.of(2020, 10, 12),"Calicut",20400);
		Employee emp2=new Employee("Chitra",LocalDate.of(1980, 02, 10),LocalDate.of(2015, 6, 12),"Chennai",40400);
		Employee emp3=new Employee("Jose",LocalDate.of(1978, 3, 10),LocalDate.of(2007, 8, 21),"Calicut",50400);
		Employee emp4=new Employee("Vani",LocalDate.of(1959, 05, 21),LocalDate.of(2000, 10, 18),"Chennai",60400);
		Employee emp5=new Employee("Rajiv",LocalDate.of(1996, 8, 10),LocalDate.of(2021, 2, 19),"Delhi",20400);
		
		employees=Arrays.asList(emp1,emp2,emp3,emp4,emp5);
		
		LocalDate today=LocalDate.now();
		
		//1. display age of given employee
//		findAgeofemployee("Chitra");
		
		//2. display top 3 senior employees
  //     findSeniorEmployee();		

       // 3. display the employee who served more than 10 years
       
   //    findTenyearoldEmployee();
		
		// 4. display employee who are retired ( retirement age is 58 )
       
	    //findRetiredEmployee();
		
		//5. display employee who is elderly in the system
	//	findElderlyEmployee();
		
		//6. display employee who will be retiring in the current month
		//findCurrentMonthRetiring();
	
		//7. current year joinee
		currentYearJoinee();
	}
	
	
static void	findAgeofemployee(String ename)
{
	LocalDate today=LocalDate.now();
    List<Employee> dobdata=employees.stream().filter( e-> e.getEmpname().equals(ename)).collect(Collectors.toList());
    dobdata.forEach(  emp ->  {
    	System.out.println("Age is " + Period.between(emp.getDob(), today));
    	
    });
} 
    
//top 3 senior
  static void    findSeniorEmployee()
  {
List<Employee> empsort= employees.stream().sorted(Comparator.comparing( emp -> emp.getDoj() )).limit(3).collect(Collectors.toList());
  empsort.forEach(System.out::println);	

  }
  
    static void   findTenyearoldEmployee()
    {
    	
//    List<Employee> result=employees.stream().filter( (e)-> Period.between(e.getDoj(), LocalDate.now()).getYears()>10 ).collect(Collectors.toList());
//      result.forEach(System.out::println);
   
    	for (Employee emp  : employees)
    	{
    		Period p=Period.between(emp.getDoj(), LocalDate.now());
    		 if (p.getYears()>10)
    			 System.out.println(emp);
    	}
    }
    

	static void    findRetiredEmployee()
	{
		
//		List<Employee> retired=employees.stream().filter(e->Period.between(e.getDob(),LocalDate.now()).getYears()>=58).collect(Collectors.toList());
//		  retired.forEach(System.out::println);

		
	   
		   for(Employee emp : employees) 
		   {
			   Period p=Period.between(emp.getDob(), LocalDate.now());
			    if (p.getYears()>=58)
			    	System.out.println(emp.getEmpname() + " is retired");
		   }
	}
	
	//elderly
	
	static void findElderlyEmployee()
	{
	  Optional<Employee> oldemp= employees.stream().min(Comparator.comparing( e-> e.getDob()));
	  
	   if(oldemp.isPresent())
		   System.out.println(oldemp.get());
	  
	}
	
	static void findCurrentMonthRetiring()
	{
		
		
		for(Employee emp : employees)
		{
			Period p=Period.between(emp.getDob(), LocalDate.now());
		//	System.out.println(p.getMonths());
			if(p.getYears()>=58)
			{
				 if ( p.getMonths()==0 )
						 
					 System.out.println(emp);
			}
		}
	}

	static void currentYearJoinee()
	{
		
		   DateTimeFormatter dtformat=DateTimeFormatter.ofPattern("yyyy/MM/dd");
		   String yeardate="2021/01/01";
		   LocalDate currdate=LocalDate.parse(yeardate, dtformat);
		   
		   for (Employee emp : employees)
		   {
			    if (emp.getDoj().isAfter(currdate))
			    	System.out.println(emp);
		   }
		 
	}
	
}
