package com.stackroute.java8dayfive;

public class Policy {

	String policyname;
	int amount;
	int period;
	public Policy(String pname,int amt,int prd)
	{
		this.policyname=pname;
		this.amount=amt;
		this.period=prd;
		
	}
	public String getPolicyname() {
		return policyname;
	}
	public void setPolicyname(String policyname) {
		this.policyname = policyname;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public String toString()
	{
		return "Policyname " + policyname + " amount" + amount;
	}
}
