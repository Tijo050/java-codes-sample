package com.stackroute.java8dayfive;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

public class SampleDateFunction {

	public static void main(String[] args) {

LocalDate today=LocalDate.now();
System.out.println(today);

LocalDate day2=today.plusDays(10);
//System.out.println(day2);

LocalDate daypast=today.minusDays(7);
//System.out.println(daypast);


LocalDate myjoindate=LocalDate.of(2015, 07, 01);
//System.out.println(" joining date is " + myjoindate );

// to replace specific part of date like day, or month or year

LocalDate date3=myjoindate.withDayOfMonth(18);
//System.out.println( " date changed " + date3);

// to get customized date using year,month,day 
LocalDate expdate=LocalDate.of(2021, 05, 10);

//to compare dates
boolean ans=expdate.isAfter(today);
/*
if(ans)
	System.out.println("Product is valid");
else
	System.out.println("Product Expired");

*/
//To customize date format

DateTimeFormatter myformat=DateTimeFormatter.ofPattern("dd/MM/yyyy");
String customtoday=today.format(myformat);

//System.out.println(customtoday);

//to convert string to date

customtoday="24/05/2021";
LocalDate customday=LocalDate.parse(customtoday,myformat);

// now() , of () , with() , parse() --> returns LocalDate with custom or builtin formats


// with Enumerators 

		LocalDate datetwowk=today.plusWeeks(2).with(DayOfWeek.SUNDAY);
 // System.out.println(datetwowk);


  					LocalDate weekend=today.with(DayOfWeek.SATURDAY);
  				//	System.out.println(weekend);
  
  			LocalDate oldfriday=today.minusDays(10).with(DayOfWeek.WEDNESDAY);
  //			System.out.println(oldfriday);

  			
  // next month first day
  			
  			
  			
  LocalDate nextmonthfday=today.plusWeeks(15).with(TemporalAdjusters.firstDayOfNextMonth());

  //System.out.println(nextmonthfday);
  

  // find age of a person
  
  LocalDate dob=LocalDate.of(2013, 12, 15);
  
  	Period perobj=Period.between(dob, today);
  	
  	System.out.println(perobj);
  	
  //	System.out.println("age " + perobj.getYears());
  	
  	LocalDate fdate=today.plusYears(perobj.getYears());
  
  	System.out.println(fdate);
  	
  	
	}

}







