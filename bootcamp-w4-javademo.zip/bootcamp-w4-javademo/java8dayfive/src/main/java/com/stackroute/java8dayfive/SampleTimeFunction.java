package com.stackroute.java8dayfive;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class SampleTimeFunction {

	public static void main(String[] args) {
		
		LocalTime currtime=LocalTime.now();
		
	//	System.out.println(currtime);
//		System.out.println("Program started");
//		System.out.println(currtime.getNano());

		LocalTime mytime=LocalTime.of(15,20,50);
		
//		System.out.println(mytime);
		
		DateTimeFormatter timeformat1=DateTimeFormatter.ofPattern("ss:mm:HH");
		String ntime="30:00:09";
		
		LocalTime mystarttime=LocalTime.parse(ntime,timeformat1);
		
		LocalTime endtimeplan=mystarttime.plusHours(8);
		
		
		
		String closetime="30:30:18";
		LocalTime myendtime=LocalTime.parse(closetime,timeformat1);
		
		
//		System.out.println("class start time" + mystarttime);
//     	  System.out.println("Planned end time " + endtimeplan);
//		
//		System.out.println(" class end time" + myendtime);
//		
  		
		
LocalTime currtime2=LocalTime.now();


		Duration duration=Duration.between(mystarttime, myendtime);
		
 //  System.out.println(duration.getSeconds());		
   
   
   LocalDateTime todaydttime=LocalDateTime.now();
   System.out.println( todaydttime);
   
   ZoneId aust=ZoneId.of("Australia/Adelaide");
   System.out.println(ZonedDateTime.now(aust));
   
// 
// 
// ZonedDateTime zonetime=ZonedDateTime.of(todaydttime,aust);
// 
// System.out.println("current zone " + zonetime.getZone());
// 
// 
// ZonedDateTime zonetime1=zonetime.withZoneSameInstant(aust);
// 
// System.out.println("canada " + zonetime1);
 

   
	}

}


