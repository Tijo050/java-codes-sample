package com.stackroute.java8dayfour;

import java.util.List;

public class Item {
		String itemname;
		String qty;
		 public String getQty() {
			return qty;
		}
		public void setQty(String qty) {
			this.qty = qty;
		}
		public Item(String iname,String qty)
		 {
			 this.itemname=iname;
			 this.qty=qty;
		 }
		public String getItemname() {
			return itemname;
		}
		public void setItemname(String itemname) {
			this.itemname = itemname;
		}
		 public String toString()
		 {
			 return itemname ;
		 }
		
}

class FoodItem
{
	  String dishname;
	  int price;
	  List<Item> items;
	  FoodItem(String dname,int pri,List<Item> itm)
	  {
		  this.dishname=dname;
		  this.price=pri;
		  this.items=itm;
	  }
	  
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	public String getDishname() {
		return dishname;
	}
	public void setDishname(String dishname) {
		this.dishname = dishname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
 
	public String toString()
	{
		return "dish name " + dishname + "price " + price + " items" + items ;
	}
}


