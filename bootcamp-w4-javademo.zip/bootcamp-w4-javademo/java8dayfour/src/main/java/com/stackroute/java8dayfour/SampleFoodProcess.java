package com.stackroute.java8dayfour;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SampleFoodProcess {

	public static void main(String[] args) {
	 
		Item item1=new Item("Sugar","1kg");
		Item item2=new Item("Ghee","1ltr");
		Item item3=new Item("Chilli powder","100gm");
		Item item4=new Item("Gingergarlic" , "5gms");
		Item item5=new Item("salt","10gms");
		
		FoodItem food1=new FoodItem("Halwa",150,Arrays.asList(item1,item2));
		FoodItem food2=new FoodItem("Chicken65",190,Arrays.asList(item3,item4,item5));
		FoodItem food3=new FoodItem("Dosa",90,Arrays.asList(item2,item5));
		FoodItem food4=new FoodItem("Payasam",100,Arrays.asList(item1,item2,item5));
		
	
		List<FoodItem> fooditems=Arrays.asList(food1,food2,food3,food4);
		
	List<FoodItem> fitem=	fooditems.stream().filter( fobj-> {
						 		
			   					List<Item> itms=fobj.getItems();
			   					
			   					//itms.stream()
			   						for(Item itm : itms)
			   							{
			   								if(itm.getItemname().equals("Sugar"))   
			   									return true;
			   								}
			   						return false;
		}).collect(Collectors.toList());
		
		
	fitem.forEach(System.out::println);
		
		
		
	}

}
