package com.stackroute.java8dayfour;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.stackroute.java8dayfour.model.Student;
import com.stackroute.java8dayfour.repo.StudentRepo;

public class SamplePartion {

	static List<Student> students=StudentRepo.getStudents();
	
	public static void main(String[] args) {
		
	Map<Boolean,List<Student>> partlist= students.stream().collect(Collectors.partitioningBy( std->std.getTotal()>1000));
	
	
	//partlist.forEach( (k,v) -> System.out.println (k + " : " + v ));
	
	
	Map<Boolean,Long> result=students.stream().collect(
								Collectors.partitioningBy( 
										std->std.getAddr().equals("Chennai"),
										Collectors.counting()
										) //partionby
								
							)  ; //colect
	
	//result.forEach( (k,v) -> System.out.println(k +"  " + v));

	
Map<Boolean,Optional<Student>> compareans=students.stream().collect(
					  							Collectors.partitioningBy(
					  											std->std.getGroupname().equals("CS"),
					  											Collectors.maxBy(Comparator.comparing( s->s.getTotal()  ))
					  										) //parti by
										); //collect
			
	compareans.forEach( (k,v)-> System.out.println( k + "value is " + v.get()));
	

	}

}
