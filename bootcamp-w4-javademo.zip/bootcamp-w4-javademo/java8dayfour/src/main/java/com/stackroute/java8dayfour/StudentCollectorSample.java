package com.stackroute.java8dayfour;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.stackroute.java8dayfour.model.Student;
import com.stackroute.java8dayfour.repo.StudentRepo;

public class StudentCollectorSample {

	static List<Student> students=StudentRepo.getStudents();
	
	public static void main(String[] args) {
		
//1. display details of student , schoolwise
	//	getListBySchool();
		
	//	2. display studentname and schoolname 
	//	getSchoolwiseStudentName();
	
		// 3. display maximum score   in each city
		//getCitywiseTopScore();
		
		//  4. display the number of students in each school
		//getSchoolbasedCount();
		
	 // 5. display top ranker in each subject
		
	//	getTopperSubjectwise();
		
		// 6.6. display average of marks in each city
		//getAverageMarksCitybased();
		
		//7. display schollname and studnet names  
		//getSchoolAndStudentNameList();
		
		//sampleJoin();
		GetSumofMarks();
		
	}

	static void getListBySchool()
	{
		
	Map<String,List<Student>> mapresult=students.stream().collect(Collectors.groupingBy( std->std.getAddr()));
	
	mapresult.forEach(  (k,v) -> System.out.println("Location "  + k + "\n" + " student list" + v));
	
	}
	
	
	static void getSchoolwiseStudentName()
	{
// Map<String,List<String>> mapdata=students.stream().collect(
//		 			Collectors.groupingBy( 
//		 									std->std.getSchoolname() , 
//		 								    Collectors.mapping( std->
//		 								    {
//		 								    return std.getName() + " " + std.getAddr();
//		 								    }
//		 								    , Collectors.toList()  ) //mapping
//		 								) //groupingby
//		 					);
// 
//	mapdata.forEach(  (k,v) ->{System.out.println(k + v);} );
 
		 Map<String,List<String>> mapdata=students.stream().collect(
		 			Collectors.groupingBy( 
		 									std->std.getSchoolname() , 
		 								    Collectors.mapping( std->std.getName(), Collectors.toList()  ) //mapping
		 								) //groupingby
		 					);

	mapdata.forEach(  (k,v) ->{System.out.println(k + v);} );
		
	
	
 
	}
	
	//topranker in a city
	
	static void getCitywiseTopScore()
	{
		
		Map<String,Optional<Student>> mapcity=students.stream().distinct().filter(std->std.getGroupname().equals("CS")).collect(
							Collectors.groupingBy(
									std->std.getSchoolname(),
									Collectors.maxBy(Comparator.comparing( std->std.getTotal()))
									) //grouping
						 	
				);//collect
		
		mapcity.forEach(  (k,v) -> {
			System.out.println("city" + k);
			System.out.println("Top ranker" + v.get());
		});
		
		
		
	}
	
	static void getSchoolbasedCount()
	{
		Map<String , Long> resdata= students.stream().collect(
								Collectors.groupingBy(
											std->std.getSchoolname(),
											Collectors.counting()
										) //grouping
									); //collect
			
		resdata.forEach( (k,v) -> System.out.println("Schoolname " + k  + " Count of studnet : " + v));
	}
	
	static void 	getTopperSubjectwise()
	{
		 Map<String,Optional<Student>> resdata = students.stream().collect(
				 Collectors.groupingBy(
						     std->std.getGroupname(),
						    Collectors.minBy(Comparator.comparing(std->std.getRank()))
						 
						 )//grouping
				  ); // collect
				 
	resdata.forEach( (k,v)->System.out.println(k + "value " + v.get()));
	}
	
	static void getAverageMarksCitybased()
	{
		
//		LinkedHashMap<String,Double> avgdata1=	students.stream().collect(
//				 Collectors.groupingBy(
//						 std->std.getAddr(),
//						 LinkedHashMap::new,
//						 Collectors.averagingInt(std->std.getTotal())
//						 ) //group
//				 
//				 	);

		
		
		
	Map<String,Double> avgdata=	students.stream().collect(
				 Collectors.groupingBy(
						 std->std.getAddr(),
						 Collectors.averagingInt(std->std.getTotal())
						 ) //group
				 
				 	);

		
	avgdata.forEach( (k,v) -> System.out.println("City : "  + k + " Average marks :" + v));
	
		
	}
	
	static void 	getSchoolAndStudentNameList()
	{
Map<String,String> mapoutput=		students.stream().collect(
											Collectors.groupingBy(
														std->std.getSchoolname(),
														Collectors.mapping(std->std.getName(), Collectors.joining("-->"))
						
															) //groupbyend
				
													); //collect ends

mapoutput.forEach( (k,v) -> System.out.println (" School " + k + " names " + v ));

		
	}
	
	
		static void sampleJoin()
		{
	String ans= students.stream().map(std->std.getName()).collect(Collectors.joining(" "));
	
	System.out.println(ans);
		}
		
		static void GetSumofMarks()
		{
			
	  	 Map<String,Integer> mapoutput=students.stream().collect( 
						 									Collectors.groupingBy( 
						 												std->std.getAddr(),
						 												Collectors.summingInt( std->std.getTotal())
						 													) //group by
	  			 											); //collect
	  	 
	  	 mapoutput.forEach( (k,v)-> { System.out.println(k + "sum is " +  v);});
	  	 
		}
	
}
