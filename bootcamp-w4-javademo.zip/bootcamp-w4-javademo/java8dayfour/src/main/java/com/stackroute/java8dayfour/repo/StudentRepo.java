package com.stackroute.java8dayfour.repo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.stackroute.java8dayfour.model.Student;




public class StudentRepo {

	static List<Student> students;
	public StudentRepo()
	{
	students=new ArrayList();	
	}
	
	public static List<Student> getStudents()
	{
		Student student1=new Student(10,"Anju","CS",1000,10,"Chennai","johns");
		Student student2=new Student(20,"Manu","CS",800,15,"Chennai","johns");
		Student student3=new Student(30,"Varun","Commerce",1100,5,"Delhi","vidhyamandir");
		Student student4=new Student(40,"Kamal","CS",900,12,"Delhi","delhipublic");
		Student student5=new Student(50,"Rakshan","Biology",1110,3,"Mumbai","vidhyamandir");
		Student student6=new Student(60,"Mary","CS",1080,9,"Mumbai","vidhyamandir");
	students=Arrays.asList(student1,student2,student3,student4,student5,student6);
	
		return students;
		
	}
	
}















