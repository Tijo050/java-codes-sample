package com.stackroute.java8dayone;

import java.util.Arrays;
import java.util.List;

interface iStudentAll
{
	 String getNamewithHighScore(Student sobj);
}

public class PersonReportAnalysis {

	static void displayStudentData(List<Student> students,iStudentAll istdall)
	{
		for(Student s : students)
		{
		if (istdall.getNamewithHighScore(s)!=null)
		System.out.println(s);
		
		}
	}
	
	public static void main(String ar[])
	{
		Student student1=new Student("S10","Annie",400,"Maths"); 
		Student student2=new Student("s11","Kumar",430,"Maths");
		Student student3=new Student("s12","Nisha",480,"Physics");
		Student student4=new Student("s13","Vimal",420,"Physics");
		Student student5=new Student("s14","Raju",380,"Biology");
		List<Student> students=Arrays.asList(student1,student2,student3,student4,student5);
//		IStudentAll stud =(sobj)->
		
		displayStudentData(students, (sobj)-> {
			   if(sobj.getTotal()>450)
				return sobj.getName();
			
			return null;
		});	
		
		
		
		
	}
}
