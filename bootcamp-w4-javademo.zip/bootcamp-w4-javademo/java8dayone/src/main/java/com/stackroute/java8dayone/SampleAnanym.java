package com.stackroute.java8dayone;

abstract class Bookstore
{
	abstract void showBooks();
	void addBook()
	{
		System.out.println("Books added");
	}
}

class MyBook extends Bookstore
{

	@Override
	void showBooks() {
		// TODO Auto-generated method stub
		
	}
	
	
}


public class SampleAnanym {

	public static void main(String[] args) {

		Bookstore book1=new MyBook();
		
Bookstore book= new Bookstore() {
								void showBooks() {
								System.out.println("books are a-apple,b-bat");
		
									}
								void addBook()
								{
									System.out.println("adding core java book");
									
								}
						};
	book.showBooks();
	book.addBook();					

	}

}
