package com.stackroute.java8dayone;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SampleForEach {
	
public static void main(String arg[])
{
  	List<String> colors=Arrays.asList("red","blue","green","yellow");
  	
//  	colors.forEach((s)->{if (s.equals("red")) 
//  							System.out.println(s.toUpperCase());
//  						}
//  				);
//  	
  	colors.forEach(System.out::println);
  	
  	
Map<String,String> countries=new HashMap<String,String>();

countries.put("uk","England");
countries.put("ind","India");
countries.put("us","America");

//countries.forEach( (k,v)-> System.out.println("country code : " + k + "   name: " + v));
  	

Student student1=new Student("S10","Annie",400,"Maths");
Student student2=new Student("s11","Kumar",430,"Maths");
Student student3=new Student("s12","Nisha",480,"Physics");
Student student4=new Student("s13","Vimal",420,"Physics");
Student student5=new Student("s14","Raju",380,"Biology");

List<Student> students=Arrays.asList(student1,student2,student3,student4,student5);

students.forEach(System.out::println);

}


}
