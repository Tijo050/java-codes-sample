package com.stackroute.java8dayone;

@FunctionalInterface
interface iBook
{
	
	// method signature, return type are called as  Functional Descriptors (FD)
	
	int calculateCost(int num);   // FD --> return type int, no of arguments - 1, data type of argu - int
	//void getAuthor(String bname);
	default void display()
	{
		System.out.println("Books printed");
	}
}
public class SampleFunctionalInterface {
	public static void main(String[] args) {

		//interface with 1 abstract method, and annotated as functionalinterface
		iBook bookobj1=new iBook()
						{
						public int calculateCost(int num) {
							return num*50;
							}
			
						};
int ans=bookobj1.calculateCost(10);

		System.out.println(ans);		
		bookobj1.display();
		iBook bookobj2=new iBook()
				{

					@Override
					public int calculateCost(int num) {
						// TODO Auto-generated method stub
						return 0;
					}
			
				};
				
				
						
//  Interface with 2 abstract methods
		
	//	iBook bookobj2=new iBook()
//				{
//
//					@Override
//					public int calculateCost(int num) {
//						// TODO Auto-generated method stub
//						return num*34;
//					}
//
//					@Override
//					public void getAuthor(String bname) {
//  
//							if(bname.startsWith("J"))
//								System.out.println("java book published at MPK");
//					}
//				
//				};
//				 			
// 			System.out.println(bookobj2.calculateCost(10));
// 			bookobj2.getAuthor("J");
		
		
	}

}




//
//class Business implements iBook
//{
//
//	@Override
//	public int calculateCost(int num) {
//		
//		
//		return 10*num;
//	}
//}
