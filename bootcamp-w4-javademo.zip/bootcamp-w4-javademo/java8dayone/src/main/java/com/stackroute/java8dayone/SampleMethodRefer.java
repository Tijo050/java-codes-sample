package com.stackroute.java8dayone;

interface iGetdata
{
	String getDetail();
}

interface iChangeData
{
	String changedata(String s);
}

interface iEmployeetest
{
	Employee getemployee();
}

public class SampleMethodRefer {

	public static void main(String[] args) {
				
		iEmployeetest empobj=Employee::new;// return instance of employee class
		Employee emp=empobj.getemployee();
		
		iGetdata getdata=new Employee()::toString;
		System.out.println(getdata.getDetail());
		
		//method reference
		
		iChangeData imydata=Employee::changeName;
		String ans=imydata.changedata("mary");
		
		System.out.println(ans);
		iChangeData myobj2=Student::check;
		System.out.println(myobj2.changedata("hello"));
		
	}

}
