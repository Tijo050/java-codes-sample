package com.stackroute.java8dayone;

interface iStudentdata
{
	  String findGroup(Student std);
}


public class SampleStudentLambda {

	public static void main(String[] args) {

		iStudentdata studobj=(s)->s.getGroup();
		

Student student1=new Student("S10","Annie",400,"Maths");


  System.out.println(studobj.findGroup(student1));
		
		
	}

}
