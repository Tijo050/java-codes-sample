package com.stackroute.java8dayone;

@FunctionalInterface
interface iCalculator
{
	
	//FD : return int, 1 param, para type - int
	
	   int calcuTax(int salary);
	   
	  default void display()
	   {
		   System.out.println("Financial Year 2021-2022");
	   }
}

interface iUser
{
	boolean validateUser(String uname,int pin);
	
}

interface iChange
{
	String changeCase(String name);
	
}

interface iHelpline
{
	int showNum();
}


public class SimpleLambda {

	public static void main(String[] args) {
		 
	iCalculator calcuobj=new iCalculator()
			{

				@Override
				public int calcuTax(int salary) {
					 return salary*18/100;
				}
		
			};
	
			System.out.println(calcuobj.calcuTax(5000));
			
	//iCalculator calcuobj1= (sal)-> {return (sal*18/100);};
			
	//iCalculator calcuobj1= (sal)->  (sal*18/100);
	
	iCalculator calcuobj1= (sal)-> sal*18/100;
	
	int ans=calcuobj1.calcuTax(5000);
	System.out.println(ans);
	

	 iUser userobj=(name, num) -> {if ( (num>0) && name.startsWith("A") )
		 							   return true;
	 								else
	 										return false;
	 							};
	 							
		 if ( userobj.validateUser("varun",40) )
	 	System.out.println("Valid user");
	    else
  	 System.out.println("Invalid user"); 							
	 							
	 							 
	 							
	 iUser userobj2=(name,n) -> n>0 && name.startsWith("A");
	
	 
	 System.out.println(userobj2.validateUser("Henry",-10));
	 
	 
	 iChange changeobj=(n)->n.toUpperCase(); 

	 changeobj.changeCase("mary");
	 
	 
	// System.out.println(changeobj.changeCase("mary"));
	 
//	 iHelpline help=()->{
//		 System.out.println("help line number is 108" );
//		return 108;
//	 };
	 
iHelpline help=() ->108;

	 int num=help.showNum();
	 
	}

}
