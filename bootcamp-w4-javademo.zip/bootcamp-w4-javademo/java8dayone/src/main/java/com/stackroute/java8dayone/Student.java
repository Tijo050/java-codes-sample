package com.stackroute.java8dayone;

public class Student {

	String rollno;
	String name;
	int total;
	String group;
	
	public Student(String rno,String nm,int tot,String gp)
	{
		this.rollno=rno;
		this.name=nm;
		this.total=tot;
		this.group=gp;
	
	}
	public String getRollno() {
		return rollno;
	}
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	
	public static String check(String s)
	{
		if (s.contains("hello"))
			return "Welcome";
		else
			return "bye";
	}
	public String toString()
	{
		return "rollno " + rollno + " Name " + name + " Group  " + group  + " mark " + total ;
	}
	
}
