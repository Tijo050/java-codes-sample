package com.stackroute.java8dayone;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


interface iStudentGroup
{
	boolean getDetail(Student s,String gpname);
}

//declare 
interface iStudentcalcu
{
	 Student findMax(Student sobj);
}
 

public class StudentReportLambda {

	static List<Student> students=new ArrayList<Student>();
	 static void findDetails(List<Student> students,iStudentGroup igroup,String gpname)
	{	
		 for(Student sobj:students)
		 {
			  if ( igroup.getDetail(sobj, gpname))
				  System.out.println(sobj);
			  
		 }
	} 
	 // defining functin findmaxdata
	 static void  findMaxData(List<Student> students,iStudentcalcu stdcalcuobj)
	 {
		   
		 for(Student sobj : students)
		 {
			// System.out.println(sobj);
			  if (stdcalcuobj.findMax(sobj)!=null)
				  System.out.println(sobj);
		 }
	 }
	 
	static void findMaxdata(iStudentcalcu cal)
	{
		
	}
	 
   public static void main(String[] args) {
   students=getStudentdata();
	   
   //callin function findMaxData with lambda expression
   
   findMaxData(students, (s)-> {if (s.getTotal()>400) return s;
   else 
	   return null;
   } );	
   
   
   iStudentcalcu calcobj=(s) -> {
	   
	   		for(Student smy : students)
	   		{
	   			if(smy.getTotal()>s.getTotal())
	   				System.out.println(smy);
	   		}
			return null;
   };
   
   //calcobj.findMax(sobj);
   
   
   
   
   
   
		iStudentGroup istudentobj= (sobj,gpname)-> {
						if(sobj.getGroup().equals(gpname))
							return true;
						else
							return false;
		};
		
		
		
// 	Scanner scan=new Scanner(System.in);
//		System.out.println("Enter the group name");
//		String gpname=scan.next();
//		findDetails(students,istudentobj,gpname);

	}
	

   
   
   static List<Student> getStudentdata()
   {
   
	Student student1=new Student("S10","Annie",400,"Maths");
	Student student2=new Student("s11","Kumar",430,"Maths");
	Student student3=new Student("s12","Nisha",480,"Physics");
	Student student4=new Student("s13","Vimal",420,"Physics");
	Student student5=new Student("s14","Raju",380,"Biology");
	List<Student> students=Arrays.asList(student1,student2,student3,student4,student5);
   return students;
   }
   
}
