package com.stackroute.java8daythree;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.stackroute.java8daythree.model.Student;
import com.stackroute.java8daythree.repo.StudentRepo;

 

public class StudentReportAnalysis {

	static List<Student> studentlist=StudentRepo.getStudents();
	
	public static void main(String[] args) {
	//1. list students who belongs to vidhyamandir school
		
		//getStudentByschollname("vidhyamandir");
		
		
// 2. list students who belongs to commerce group and secured above 1000 marsk
		//getStudentsByGroupAndMark("commerce",1000);	
		
	//	3. list student names  which is having rank to be less than 5
	//	getSchoolNameByRank(10);
		
		
		//4.  get student data who scored maximum / minimum
		
	//	getMaximumTotal();
		
		// 5. list the student data in ascending order of mark secured
	//	sortStudentMarkAscending();
		
		// 6. list the average marks for the given city 
		//getAverageMarksInCity("Chennai");
		
		// 7. list schoolname, studenname who secured above 1000
	//	getSchoolAndStudentSecuredMore(1000);
		
		
		// 8. list highestscore in the given schoolname
		
		getHighestScoreInSchool("johns");
		
		// 9. list topper in the given school
		
		getTopperinSchool("delhipublic");
	}

	static void getStudentByschollname(String school)
	{
		Predicate<Student> prescholl=(sobj)->sobj.getSchoolname().equals(school);
		
	List<Student> studentresult=studentlist.stream().filter(prescholl).collect(Collectors.toSet());
	
		
	studentresult.forEach(System.out::println);
	
	}
	
	static void getStudentsByGroupAndMark(String group,int mark)
	{
	
		Predicate<Student> pregroup=(sobj)->sobj.getGroupname().toLowerCase().equals(group);
		Predicate<Student> premark=(sobj)->sobj.getTotal()>=mark;
		
		Predicate<Student> preall=pregroup.and(premark);
		
		List<Student> studentresult=studentlist.stream().filter(preall).collect(Collectors.toList());
		
		
		studentresult.forEach(System.out::println);
			
		
	}
	
	static void getSchoolNameByRank(int rk)
	{
		Predicate<Student> predicateobj=(sobj)-> sobj.getRank()<rk;
		
	List<String> studentnames=studentlist.stream().filter(predicateobj).map((stuobj)-> stuobj.getGroupname() ).collect(Collectors.toList());
		
	studentnames.forEach(System.out::println);
		
	}
	
	static void getMaximumTotal()
	{
		

//	if(maxscore.isPresent())
//		System.out.println(maxscore.getAsInt());
//	 Comparator abstract method compare(object,object2) : int 
		
//	Comparator<Student> compareobj= (stud1,stud2) ->
//									{	
//										if(stud1.getTotal()==stud2.getTotal())
//											return 0;
//										else if(stud1.getTotal()<stud2.getTotal())
//											return -1;
//										else
//											return 1;
//									};
		
//	Optional<Student> optstud=studentlist.stream().min(compareobj);
//		
//	if(optstud.isPresent())
//		System.out.println(optstud.get());
	
//alternate	
	
//		OptionalInt maxscore=studentlist.stream().mapToInt( (sobj)-> sobj.getTotal()).max();
		
Optional<Student> optstud1=	studentlist.stream().min(Comparator.comparing( (stud)->stud.getTotal()));
	
if(optstud1.isPresent())
System.out.println(optstud1.get());


	}
	
	static void sortStudentMarkAscending()
	{

	//	studentlist.stream().sorted(Comparator.comparing( (sobj)->sobj.getTotal() )).collect(Collectors.toList());
	
List<Student> sortedlist=studentlist.stream().sorted(Comparator.comparing(Student::getTotal)).collect(Collectors.toList());
		
//List<Student> sortedlist=studentlist.stream().sorted(Comparator.comparing(Student::getTotal).reversed()).collect(Collectors.toList());


	sortedlist.forEach(System.out::println);

		
		
	}

	static void getAverageMarksInCity(String cityname)
	{
	
		//Predicate<Student> precity = (sobj) -> sobj.getAddr().equals(cityname);
		//OptionalDouble avg=studentlist.stream().filter(precity).mapToInt( sobj->sobj.getTotal()).average();

		
	OptionalDouble avg=studentlist.stream().filter((sobj) -> sobj.getAddr().equals(cityname)).mapToInt( sobj->sobj.getTotal()).average();
	
	if(avg.isPresent())
		System.out.println(avg.getAsDouble());
		
	}
	
	static void getSchoolAndStudentSecuredMore(int tot)
	{
		
		Predicate<Student> premark=(sobj)->sobj.getTotal()>tot;
		
		
		Map<String,String> mapresult=studentlist.stream().filter(premark).collect(Collectors.toMap(Student::getName, Student::getSchoolname));
		
		mapresult.forEach( (k,v) -> System.out.println(k + " scholl nmae : "  + v));
		
		
// Map with string and object
// Map<String,Student> mapresult=studentlist.stream().filter(premark).collect(Collectors.toMap(Student::getName, sobj->sobj));
//	mapresult.forEach( (k,v) -> System.out.println(k + " : "  + v.getGroupname() + v.getSchoolname() ));
		
	}
	
	void convertListtoLinked()
	{
	//LinkedList<Student> llist= studentlist.stream().collect(Collectors.toCollection(()-> new LinkedList()));
	
		LinkedList<Student> llist= studentlist.stream().collect(Collectors.toCollection(LinkedList::new));
		
	}
	
	
	
	static void getHighestScoreInSchool(String schoolname)
	{
	OptionalInt maxmark= studentlist.stream().filter( s-> s.getSchoolname().equals(schoolname)).mapToInt(s->s.getTotal()).max();
	
	if (maxmark.isPresent())
		System.out.println(maxmark.getAsInt());
	}
	
	
	static void getTopperinSchool(String schoolname)
	{
	Optional<Student> sobj=studentlist.stream().filter( s->s.getSchoolname().equals(schoolname)).max(Comparator.comparing(Student::getTotal));
	
	if (sobj.isPresent())
		System.out.println(sobj.get());
			
		
	}
}
