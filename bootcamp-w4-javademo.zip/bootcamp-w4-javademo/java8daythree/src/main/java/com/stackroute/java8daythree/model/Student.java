package com.stackroute.java8daythree.model;

public class Student {

	int rollno;
	String name;
	String groupname;
	int total;
	int rank;
	String addr;
	String schoolname;
   	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getSchoolname() {
		return schoolname;
	}
	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}
	public Student(int rno,String nm,String gp,int tot,int rk, String addr,String sname)
   	{
   		this.rollno=rno;
   		this.name=nm;
   		this.groupname=gp;
   		this.total=tot;
   		this.rank=rk;
   		this.addr=addr;
   		this.schoolname=sname;
   				
   	}
	
   	public String toString()
   	{
   		return "name " + name + " rank " + rank + " group name " + groupname + " schoolname" + schoolname + "addr " + addr + " Total " + total;
    	}
   	
	
}
