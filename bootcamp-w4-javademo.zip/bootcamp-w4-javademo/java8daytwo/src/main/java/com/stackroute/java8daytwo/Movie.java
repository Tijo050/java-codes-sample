package com.stackroute.java8daytwo;

public class Movie implements Comparable{

	 String movieName;
	 int noofdays;
	 String director;
	 
	 public Movie(String mov,int days,String director)
	 {
		 this.movieName=mov;
		 this.noofdays=days;
		 this.director=director;
	 }
	 public String toString()
	 {
		 return "Movie " + movieName + " no of day " + noofdays  + " direct " + director;
	 }
	 
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getNoofdays() {
		return noofdays;
	}
	public void setNoofdays(int noofdays) {
		this.noofdays = noofdays;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	@Override
	public int compareTo(Object obj) {
	 Movie mnew=(Movie) obj;
		
		return this.getNoofdays()-mnew.getNoofdays();
	}
	 
	
}
