package com.stackroute.java8daytwo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

import com.stackroute.java8daytwo.repo.MovieRepo;

public class MovieAnalysis {

	public static void main(String[] args) {

		List<Movie> movielist=MovieRepo.getMovies();
		
		Predicate<Movie> preprofit=(pobj)-> pobj.getNoofdays()>300;
		
		BiPredicate<Movie,String> bipredic= (movobj,dname) -> movobj.getDirector().equals(dname);
		
		
		Optional<List<Movie>> optmovieresult=filterMaxProfitmovie(movielist,preprofit);
		if(optmovieresult.isPresent())
		{
			List<Movie> movieresult=optmovieresult.get();

		movieresult.forEach(System.out::println);
		}
		
		List<Movie> mdirector=filterByDirector(movielist,bipredic);
		mdirector.forEach(System.out::println);
		
	}
	static List<Movie> filterByDirector(List<Movie> movies,BiPredicate bifilter)
	{
		List<Movie> movielistdirector=new ArrayList<Movie>();
		
		System.out.println("Enter director name");
		Scanner scan=new Scanner(System.in);
		String director=scan.next();
			
		for(Movie m : movies)
		{
				  if (bifilter.test(m,director))
					  movielistdirector.add(m);
			}
		
		return movielistdirector;
		
	}

	static Optional<List<Movie>> filterMaxProfitmovie(List<Movie> movies,Predicate prefilter)
	{
		List<Movie> movielistprofit=new ArrayList<Movie>();
		
		for(Movie m : movies)
		{
			if( prefilter.test(m) )
			  movielistprofit.add(m);
				
		}
		
		Optional<List<Movie>> movieopt=Optional.of(movielistprofit);
									
		
		return movieopt;
		
		
	}
	

	
}
