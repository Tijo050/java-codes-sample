package com.stackroute.java8daytwo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;

import com.stackroute.java8daytwo.repo.MovieRepo;

public class MovieReportFunction {

	public static void main(String[] args) {

		 List<Movie> movies=MovieRepo.getMovies();
		 
		 List<String> movielist=new ArrayList();
		 
		 Function<Movie,String> funmovie= (movobj)->
		 {
			  if(movobj.getNoofdays()>100)
				return movobj.getMovieName();
			  else
			  return  "";
			  
		 };
		
		 getMovieList(movies,funmovie);
		 
		 
	}
	
	static void getMovieList(List<Movie> movies , Function fun)
	{
		ArrayList<String> result=new ArrayList<String>();
		
		 for(Movie mobj : movies)
		 {
			result.add( fun.apply(mobj).toString());
		 }
		 
		 result.forEach(System.out::println);
		// System.out.println(result);
	}

}
