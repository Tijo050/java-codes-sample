package com.stackroute.java8daytwo;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import com.stackroute.java8daytwo.repo.MovieRepo;

public class MovieReportwithConsumer {

	public static void main(String[] args) {

		List<Movie> movielist=MovieRepo.getMovies();
		Consumer<Movie> consumemovie=(mov) -> {
				if(mov.getNoofdays()<100)
					System.out.println(mov.getMovieName() + " Non Profitable");
				else if(mov.getNoofdays()<300)
					System.out.println(mov.getMovieName() + " Profit");
				else 
					System.out.println(mov.getMovieName() + " Super hit!!!!");
			
		};
		BiConsumer<Movie,Integer> biconsume=(mov,perdayamount) -> {
			if(mov.getNoofdays()<100)
				System.out.println(mov.getMovieName() + " Non Profitable " +  " Collection amount" +  perdayamount.intValue() *  mov.getNoofdays());
			else if(mov.getNoofdays()<300)
				System.out.println(mov.getMovieName() + " Profit" + " Collection amount" +  perdayamount.intValue() *  mov.getNoofdays());
			else 
				System.out.println(mov.getMovieName() + " Super hit!!!!" + " Collection amount" +  perdayamount.intValue() *  mov.getNoofdays());
		
	};
		
movielist.forEach(consumemovie);
		
//		movielist.forEach(
//				 (m)-> biconsume.accept(m,2000)
//				
//				);
		
		for(Movie m : movielist)
		{
			biconsume.accept(m,2000);
		}
		
	}

}
