package com.stackroute.java8daytwo;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.stackroute.java8daytwo.repo.MovieRepo;

public class MovieSortSample {

	public static void main(String[] args) {
	 
		List<Movie> movies=MovieRepo.getMovies();
		
//		Collections.sort(movies);
//		movies.forEach(System.out::println);
		
//		movies.sort( 
//				(mov1,mov2)->
//				mov2.getMovieName().compareTo(mov1.getMovieName())
//					
//				);
//		  movies.forEach(System.out::println);
	
		   
		
		
		  Comparator<Movie> compareobj= (mov1,mov2)->
		  	{
		  			if(mov1.getNoofdays()==mov2.getNoofdays())
		  				return 0;
		  			else if (mov1.getNoofdays()<mov2.getNoofdays())
		  				return 1;
		  			else
		  				return -1;
		  	};
		  	
		  	movies.sort(compareobj);
		  	
		  	movies.forEach(System.out::println);
		  	
		
	}

}
