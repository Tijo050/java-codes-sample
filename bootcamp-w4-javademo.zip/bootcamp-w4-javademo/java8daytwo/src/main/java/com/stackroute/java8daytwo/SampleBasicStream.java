package com.stackroute.java8daytwo;

import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.Collectors;

import com.stackroute.java8daytwo.repo.MovieRepo;

public class SampleBasicStream {

	public static void main(String[] args) {

		
				
		
		List<Movie> movielist=MovieRepo.getMovies();
		 
//	long ans=movielist.stream().filter( mov-> mov.getDirector().startsWith("S")).count();
//		System.out.println("no of movies direced by names starts with S  " + ans);
		
		
//List<Movie> topmovies=movielist.stream().filter( mov-> mov.getNoofdays()>100).collect(Collectors.toList());
//topmovies.forEach(System.out::println);
		
//movielist.stream().filter( mov-> mov.getNoofdays()>100).collect(Collectors.toList()).forEach(System.out::println);


//boolean result=movielist.stream().allMatch( (m)->m.getNoofdays()>100);
//if(result)
//	System.out.println("all are super hit movies");
//	
//else
//	System.out.println(" Flop movies exist");

//Optional<Movie> optmovie=movielist.stream().filter( mov-> mov.getDirector().startsWith("S")).findFirst();
//		
//if(optmovie.isPresent())
//	System.out.println(optmovie.get());
//else
//	System.out.println("No such director whose name start with S");
//		


//movielist.stream().limit(3).filter( mov-> mov.getNoofdays()>100).collect(Collectors.toList()).forEach(System.out::println);

//movielist.stream().skip(3).filter( mov-> mov.getNoofdays()>100).collect(Collectors.toList()).forEach(System.out::println);

List<String> directorlist=movielist.stream().filter(mov->mov.getNoofdays()>100).map( (mov)->mov.getMovieName() ).collect(Collectors.toList());
//directorlist.forEach(System.out::println);
		

//movielist.stream().map( mov->mov.getDirector()).filter( str-> str.startsWith("S") ).collect(Collectors.toList()).forEach(System.out::println);

OptionalInt result=movielist.stream().mapToInt( mov-> mov.getNoofdays()).min();

if(result.isPresent())
	System.out.println("Minimum no of days " + result.getAsInt());

	}

}
