package com.stackroute.java8daytwo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class SampleConsumer {

	public static void main(String[] args) {
		
		Consumer<String> consumedisplay= (str)->{System.out.println(str.toUpperCase());};
		
		List<String> fruits=Arrays.asList("Apple","mango","Orange","pineapple","papaya");
		
		
		//using consumer object as an argument to builtin method of java
		fruits.forEach(consumedisplay);
		
	
		
		// explicitly calling abstract method of consumer
		for(String f : fruits)
		{
			consumedisplay.accept(f);
		}
		
		
		
		BiConsumer<String ,String> biconsume=(arg1,arg2)->{
		     if(arg2.startsWith("M"))	
			System.out.println("Key " + arg1 + "value " + arg2);
			
		};
			
		Map<String ,String> mymap=new HashMap();
		mymap.put("1","Mouse");
		mymap.put("2","Monitor");
		mymap.put("3","CPU");
		
		mymap.forEach(biconsume);
		
		
	}

}
