package com.stackroute.java8daytwo;

import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;

public class SampleFunction {

	public static void main(String[] args) {

		
		Function<String,Integer> myfun=(str)->{
			System.out.println("element is " + str);
			return str.length();
		
		};
		
		BiFunction<String,String,String> bifun=(str1,str2)->str1+str2;
		System.out.println(bifun.apply(" Tijo " , "Varghese"));
		
	
		
		List<String> fruits=Arrays.asList("Apple","mango","Orange","pineapple","papaya");
	
		
		
		
		for(String frt : fruits)
		{
			
			 System.out.println(myfun.apply(frt));
		}
		
		
	}

}
