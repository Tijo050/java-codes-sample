package com.stackroute.java8daytwo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public class SamplePredicate {

	public static void main(String[] args) {
		
		String s;

		Predicate<String> preobj=(str)-> str.endsWith("e");
		
	List<String> fruits=Arrays.asList("Apple","mango","Orange","pineapple","papaya");
	
	Predicate<String> prelen= (str) -> str.length()>5;
  
	//accessing predicate by calling test method

		
	System.out.println("After applying predicate");
	
	Predicate<String> prenegat=preobj.negate();
	
	
	Predicate<String> preboth= preobj.and(prelen);
	
	for(String frt : fruits)
	{
	 if(	preboth.test(frt))
		 System.out.println(frt);
	}
	
	
	//accessing predicate by passing its object as parameter in builtin java function
	ArrayList fruitarr=new ArrayList();

	
	fruitarr.addAll(fruits);
	
   
	fruitarr.removeIf(prenegat);

    fruitarr.forEach(System.out::println);
	
   
   
   
	}

}
