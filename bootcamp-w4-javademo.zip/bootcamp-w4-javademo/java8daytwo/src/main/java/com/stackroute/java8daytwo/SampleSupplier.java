package com.stackroute.java8daytwo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.function.Supplier;

public class SampleSupplier {

	public static void main(String ar[])
	{
		Supplier supplyobj=() -> {
			  List lst=Arrays.asList("java8","angular","spring");
			return lst;
				};
		
		System.out.println(supplyobj.get());
		
		
	}
}
