package com.stackroute.java8daytwo.repo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.stackroute.java8daytwo.Movie;

public class MovieRepo {

	public MovieRepo()
	{
		
	}
	
	public static List<Movie> getMovies()
	{
		Movie movie1=new Movie("Terminator",300,"Stephen");
		Movie movie2=new Movie("End of the days",450,"Philip");
		Movie movie3=new Movie("2026",110,"Stephen");
		Movie movie4=new Movie("Wrong turn",80,"Peter");
		
		Movie movie5=new Movie("Apocalypo",400,"Samson");
		
		List<Movie> movies=Arrays.asList(movie1,movie2,movie3,movie4,movie5);
		return movies;
		
	}
}
