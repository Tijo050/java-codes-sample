package com.ustg.employee;

import java.util.List;
import java.util.Scanner;

import com.ustg.employee.exception.EmployeeAlreadyExistException;
import com.ustg.employee.exception.EmployeeNotFoundException;
import com.ustg.employee.model.Employee;
import com.ustg.employee.service.EmployeeServiceImpl;
import com.ustg.employee.service.iEmployeeService;

public class EmployeeProcess {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		iEmployeeService empservice=new EmployeeServiceImpl();
	String ch="y";
		while (ch.equals("y"))
		{
			System.out.println("1-view,2-add,3-find");
			int choice=scan.nextInt();
		switch(choice)
		{
		case 1:
				List<Employee> emplist=empservice.viewAllEmployee();
				System.out.println(emplist);
				break;
		case 2:
			Employee empnew =new Employee(26,"Mary");
			try {
				empservice.addEmployee(empnew);
				System.out.println("added");
			} catch (EmployeeAlreadyExistException e) {
				 System.out.println(e.getMessage());
			}
			break;
		case 3:
			  try {
				Employee empresult=empservice.findByEmployeeId(45);
				System.out.println(empresult);
			} catch (EmployeeNotFoundException e) {
				 
				System.out.println(e.getMessage());
			}
			  break;
			 default:
				  break;
	} // switch
		
		  System.out.println("want to continue");
		  ch=scan.next();
		}

}
}