package com.ustg.employee.exception;

public class EmployeeAlreadyExistException extends Exception {

	  public EmployeeAlreadyExistException(String msg)
	  {
		  super(msg);
	  }
	
}
