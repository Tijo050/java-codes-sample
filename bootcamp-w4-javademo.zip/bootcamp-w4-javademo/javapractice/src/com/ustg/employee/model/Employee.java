package com.ustg.employee.model;

public class Employee {

	int employeeId;
	String empname;
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		
		this.employeeId = employeeId;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}
 public  Employee()
     {
    	 
     }
	public Employee(int empid,String ename)
	{
		this.employeeId=empid;
		this.empname=ename;
	}
	
	public String toString()
	{
		return " id is " + employeeId + " Name is : " + empname;
	}
	
}
