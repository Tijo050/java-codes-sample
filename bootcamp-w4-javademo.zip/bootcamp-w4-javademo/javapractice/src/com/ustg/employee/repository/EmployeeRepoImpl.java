package com.ustg.employee.repository;

import java.util.ArrayList;
import java.util.List;

import com.ustg.employee.model.Employee;

public class EmployeeRepoImpl implements iEmployeeRepo {

	ArrayList<Employee> employeelist=new ArrayList<Employee>();
	
	public EmployeeRepoImpl()
	{
		Employee emp1=new Employee(10,"Arun");   
		Employee emp2=new Employee(20,"Ajay");  
		Employee emp3=new Employee(30,"Rasagna");  
		employeelist.add(emp1);
		employeelist.add(emp2);
		employeelist.add(emp3);
		
	}
	
	@Override
	public void add(Employee empnew) {
		 
		employeelist.add(empnew);
	}

	@Override
	public List<Employee> viewAll() {
		
		return employeelist;
	}

	@Override					  	
	public Employee findById(int id) {
		Employee empresult=null; 
		
		for(Employee emp : employeelist)
		{
			  if(emp.getEmployeeId()==id)
				  empresult=emp;
				  
		}
		return empresult;
	}

}
