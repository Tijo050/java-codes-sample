package com.ustg.employee.repository;

import java.util.List;

import com.ustg.employee.model.Employee;

public interface iEmployeeRepo {

	    void add(Employee emp);
	     List<Employee>    viewAll();
	      Employee findById(int id);
}
