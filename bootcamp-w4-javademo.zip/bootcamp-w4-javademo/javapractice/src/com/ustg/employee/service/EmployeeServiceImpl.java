package com.ustg.employee.service;

import java.util.ArrayList;
import java.util.List;

import com.ustg.employee.exception.EmployeeAlreadyExistException;
import com.ustg.employee.exception.EmployeeNotFoundException;
import com.ustg.employee.model.Employee;
import com.ustg.employee.repository.EmployeeRepoImpl;
import com.ustg.employee.repository.iEmployeeRepo;

public class EmployeeServiceImpl implements iEmployeeService {

	iEmployeeRepo emprepo=new EmployeeRepoImpl();
	
	List<Employee> empservicelist=emprepo.viewAll();
	
	public EmployeeServiceImpl()
	{
		//empservicelist=emprepo.viewAll();
	}
	
	//empnew -- 20,Mary
	@Override
	public void addEmployee(Employee empnew) throws EmployeeAlreadyExistException {
		 
		char ch='n';
		for(Employee emp : empservicelist)
		{
			if (emp.getEmployeeId()==empnew.getEmployeeId())
				ch='y';
		}
		
		if(ch=='y')
			throw new EmployeeAlreadyExistException("duplicate id");
		
		emprepo.add(empnew);
		
		
	}

	@Override
	public List<Employee> viewAllEmployee() {
		
		 return emprepo.viewAll();
	}

	@Override
	public Employee findByEmployeeId(int id) throws EmployeeNotFoundException {
	Employee empobj=	emprepo.findById(id);
		
	if (empobj==null)
		throw new EmployeeNotFoundException("Emp id doesnt exist");
	
	return empobj;
	}

}
