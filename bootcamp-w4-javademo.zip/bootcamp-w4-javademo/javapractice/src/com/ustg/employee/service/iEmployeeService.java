package com.ustg.employee.service;

import java.util.List;

import com.ustg.employee.exception.EmployeeAlreadyExistException;
import com.ustg.employee.exception.EmployeeNotFoundException;
import com.ustg.employee.model.Employee;

public interface iEmployeeService {

	void addEmployee(Employee emp) throws EmployeeAlreadyExistException;
	List<Employee> viewAllEmployee();
	Employee findByEmployeeId(int id) throws EmployeeNotFoundException;
	
	
}
