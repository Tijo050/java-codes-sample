package com.stackroute.sampletestdemo;

public class BankProcess {
public String findPolicy(int age)
{
	if (age<10)
		return "children";
	else if (age<=19)
		return "study";
	else if (age<40)
		return "work";
	else if(age<60)
		return "pension";
	else
		return "ayushman";
}
	
}
