package com.stackroute.sampletestdemo;

public class NegativeNumberException extends Exception{

	public NegativeNumberException(String msg)
	{
		super(msg);
	}
}
