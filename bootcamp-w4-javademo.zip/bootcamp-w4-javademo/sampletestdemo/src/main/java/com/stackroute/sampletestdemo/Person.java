package com.stackroute.sampletestdemo;

public class Person {
 int pid;
 String pname;
 public Person() {}
 
 public Person(int pid,String pname)
 {
	 this.pid=pid;
	 this.pname=pname;
 }
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}

public boolean validateName()
{
	if(pname.length()<=3)
		return false;
	else
		return true;
}
public boolean validateId() throws NegativeNumberException
{
	if(pid<=0)
		throw new NegativeNumberException("id should not be negative");
	return true;
	
}

 
}
