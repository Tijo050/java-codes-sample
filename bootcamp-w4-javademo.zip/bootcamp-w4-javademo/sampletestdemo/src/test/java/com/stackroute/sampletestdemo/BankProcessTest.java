package com.stackroute.sampletestdemo;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

//import static org.junit.runners.parameterized.*;

import java.util.Collection;

@RunWith(Parameterized.class)
public class BankProcessTest {

	int age;
	String policytype;
	BankProcess bankobj;
	public BankProcessTest(int age,String policy)
	{
		super();
		
		this.age=age;
		this.policytype=policy;
	}
	
	@Before
	public void initialize()
	{
		bankobj=new BankProcess();
	}
	
	@Parameters
	public static Collection inputdata()
	{
	   
		return Arrays.asList(
				
				new Object[][]
						{
					{4,"children"},
					{14,"study"},
					{35,"work"},
					{89,"ayushman"}
						}
				
				
				);
		}

   @Test
   public void testAge()
   {
	   assertEquals(policytype,bankobj.findPolicy(age));
   }
   
}

