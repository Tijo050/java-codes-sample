package com.stackroute.sampletestdemo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertAll;

import java.time.Duration;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import junit.framework.Assert;

public class PersonTest {
Person personobj=new Person(100,"Devi");

@Test
public void testNamenotNull()
{
	Assert.assertEquals("Devi", personobj.getPname() );
}

@Test
public void testIDNonnullsucess()
{
	//personobj.setPid(null);
	Assert.assertNotNull(personobj.getPid());
}

@Test
public void testPersonNameValidFailure()
{
	personobj.setPname("aru");
	
	Assert.assertEquals(false, personobj.validateName());

}

@Test
public void whennegativeidthenexception()
{
	personobj.setPid(-15);
	
	Exception exceptionobj=assertThrows(NegativeNumberException.class,
			()-> personobj.validateId()
			
			);
	
    Assert.assertEquals("id should not be negative", exceptionobj.getMessage());
}


@Test
public void whenvaliddatathenexcecute()
{
	Assertions.assertAll("validating userid and password", 
			 ()-> {
				  assertNotNull(personobj.getPname());
				  
				  assertAll( "checking name and pwd not null",
						 
					  ()->assertEquals("Devi",personobj.getPname()),
					  ()->assertEquals(100,personobj.getPid())
				   
			 
						  ); //inner assertall

			 }
			
			
			
			); //outer assertall
}

	@Test
	public void testdurationofnamevalidate()
	{
		
	boolean ans=Assertions.assertTimeout(Duration.ofMinutes(1),
				()->
		{
			 boolean result=personobj.validateId();
			 return result;
		});
	
	
	assertEquals(true,ans);
	}






}
