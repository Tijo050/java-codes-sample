package com.stackroute.studentdata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

class StudentDb
{
	
	Connection connection;
	Connection getConnect() throws Exception
	{
	   Class.forName("com.mysql.cj.jdbc.Driver");	
	connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/ustbootcamp3","root","password");
	   return connection;
	}
	
	StudentDb() throws Exception
	{
		getConnect();
	}
	public boolean storeRecord() throws Exception
	{
		Statement statement=connection.createStatement();
		
		statement.executeUpdate("insert into student values(300,'Raju')");
		
		return true;
	}
	public boolean deleteRecord(int rollno) throws Exception
	{
	PreparedStatement prepare=connection.prepareStatement("delete from student where rollno=?");
	prepare.setInt(1, rollno);
	return prepare.execute();
	}
	
	public void displayRecord() throws Exception
	{
		Statement statement=connection.createStatement();
		ResultSet rs=statement.executeQuery("select * from  student");
		while (rs.next())
		{
			System.out.println(rs.getString(1) + rs.getString(2));
		}
	}
}


public class StudentDataProcess {

public static void main(String[] args) throws Exception {
 
StudentDb studentobj=new StudentDb();
//studentobj.storeRecord();
//		 System.out.println("Record Stored");
//		studentobj.deleteRecord(100);

studentobj.displayRecord();
	}

}
